<?php echo e($slot); ?>

<?php /**PATH /home/u518791033/domains/web-terminal.online/public_html/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>