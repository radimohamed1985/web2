<?php $__env->startSection('content'); ?>


    <div class="verification section-padding">
        <div class="container h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-xl-5 col-md-6">
                    <div class="auth-form card">
                        <div class="card-body">
                            <form action="<?php echo e(route('backend.id.proceed')); ?>" class="identity-upload">
                                <div class="identity-content">
                                    <span class="icon"><i class="fa fa-shield"></i></span>
                                    <h4>We are uploading your ID</h4>
                                    <p>Your identity is being uploaded. We will email you once your verification has
                                        verified.
                                    </p>
                                </div>

                                <div class="upload-loading text-center mb-3">
                                    <i class="fa fa-spinner fa-spin fa-3x fa-fw"></i>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script>

        window.setTimeout(function () {
            window.location.href = "<?php echo e(route('backend.id.proceed')); ?>";
        }, 2000);
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master-min', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u518791033/domains/web-terminal.online/public_html/resources/views/backend/profile/id-processing.blade.php ENDPATH**/ ?>