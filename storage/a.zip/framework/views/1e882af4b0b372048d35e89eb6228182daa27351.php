<?php $__env->startSection('style'); ?>
<?php echo $__env->make('admin.partials.dt-css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    .dataTables_paginate {
        display: none;
    }
    .dataTables_info {
        display: none;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="br-mainpanel">

        <div class="br-pagebody">
            <div class="br-section-wrapper">

                <?php if(auth()->user()->hasRole(['superadmin'])): ?>
                <a class="btn btn-primary m-1" href="<?php echo e(route('admin.users.ids')); ?>">KYC Verifications</a>
                <a class="btn btn-primary m-1" href="<?php echo e(route('admin.plans.index')); ?>">Plans</a>
                <a class="btn btn-dark m-1" href="<?php echo e(route('admin.deposits.index')); ?>">Deposits</a>
                <a class="btn btn-success m-1" href="<?php echo e(route('admin.withdrawals.index')); ?>">Withdrawal</a>
                <a class="btn btn-success m-1" href="<?php echo e(route('admin.transactions')); ?>">Transactions</a>

                    
            <?php endif; ?>

            </div>
        </div>
        <div class="br-pagebody" id="vue-content">

            <div class="br-section-wrapper">

                <?php echo $__env->make('notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <h6 class="tx-gray-800 tx-uppercase tx-bold tx-14 mg-b-10" style="padding-bottom: 50px">

                    <?php if(auth()->user()->hasRole(['superadmin','admin'])): ?>

                    <button class="btn btn-success m-1" data-toggle="modal" data-target="#bulkAction"> Bulk Action </button>


                        <div class="dropdown d-inline">
                            <button class="btn btn-success dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Assign Manager <i class="fa fa-spinner fa-spin" v-if="changingManager"></i>
                            </button>
                            <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                                <?php $__empty_1 = true; $__currentLoopData = $managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <button class="dropdown-item" type="button" v-on:click="setManagerAs(<?php echo e($manager->id); ?>)"><?php echo e($manager->name); ?></button>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <button class="dropdown-item" type="button">No Manager Avaialable </button>
                                <?php endif; ?>
                            </div>
                        </div>



                        <div class="dropdown d-inline">
                            <button class="btn btn-success dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Assign Retention <i class="fa fa-spinner fa-spin" v-if="changingManager"></i>
                            </button>
                            <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                                <?php $__empty_1 = true; $__currentLoopData = $retentions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <button class="dropdown-item" type="button" v-on:click="setManagerAs(<?php echo e($manager->id); ?>)"><?php echo e($manager->name); ?></button>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <button class="dropdown-item" type="button">No Manager Avaialable </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    <a href="<?php echo e(route('admin.verify.accounts')); ?>"><button class="btn btn-success m-1" style="float: right">Verify all emails</button></a>

                    <?php endif; ?>
                    <?php if(auth()->user()->hasRole(['superadmin'])): ?>
                        <a href="<?php echo e(route('admin.users.create')); ?>?r=user"><button class="btn btn-warning m-1" style="float: right"> Add  Customer</button></a>

                    <?php endif; ?>


                        <?php if(auth()->user()->hasRole(['superadmin','admin'])): ?>
                            <?php if(setting('autotrader')): ?>
                        <a href="<?php echo e(route('admin.users.create')); ?>?r=autotrader"><button class="btn btn-primary m-1" style="float: right"> Add Autotrader</button></a>
                            <?php endif; ?>
                    <?php endif; ?>
                </h6>


            <div class="table-wrapper table-responsive">
                <form action="<?php echo e(route('admin.users.index')); ?>" method="get">
                    <div class="row mb-4">
                      <div class="col-2"></div>
                        <?php if(auth()->user()->hasRole(['superadmin','admin'])): ?>
                        <?php if(is_active('admin.users.index')): ?>
                      <div class="col-2">
                        <select class="form-control" name="manager">
                            <option value="" class="text-muted">Filter Manager</option>
                            <?php $__currentLoopData = $managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($manager->id); ?>" <?php if(Request::get('manager') == $manager->id ): ?> selected <?php endif; ?>><?php echo e($manager->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                        <?php endif; ?>
                        <?php endif; ?>
                      <div class="col-4">
                        <input type="text" class="form-control" name="q" value="<?php echo e(Request::get('q')); ?>" placeholder="Search">
                      </div>
                      <div class="col-2">
                          <button class="btn btn-primary"><em class="fa fa-search"></em></button>
                          <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-danger"><em class="fa fa-times text-white"></em></a>
                      </div>
                      <div class="col-2"></div>
                    </div>
                  </form>

                <table id="datatable"  style="width: 100%;">
                <thead>
                    <tr>
                        <?php if(auth()->user()->hasRole(['superadmin','admin'])): ?>
                        <th class="wd-2p">
                            <input type="checkbox" v-model="selectAllUsers"/>
                        </th>
                        <?php endif; ?>
                        <th>ID</th>
                        <th class="w-25">Name</th>
                    <th  class="w-35">Email</th>
                    <th class="w-25">Phone</th>
                            <th class="w-25">Status</th>
                            <th class="w-25">Manager</th>
                    <th class="w-25">Source</th>

                            <?php if(setting('invest')): ?>
                                <th class="wd-10p">Invested</th>
                            <?php endif; ?>
                            <?php if(auth()->user()->hasRole(['superadmin'])): ?>
                    <th class="w-50">Trades</th>
                    <th class="w-50">Finance</th>
                    <?php endif; ?>
                       <th class="w-50">Created at</th>



                    </tr>
                </thead>
                <tbody>

                    <?php
                        $count = 1;
                    ?>
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr v-cloak>
                            <?php if(auth()->user()->hasRole(['superadmin','admin'])): ?>
                            <td width="2">
                                    <input type="checkbox" value="<?php echo e($user->id); ?>" v-model="selected_users"/>
                                



                            </td>
                            <?php endif; ?>
                            <td><?php echo e($user->id); ?></td>
                            <td><a class="text-capitalize" href="<?php echo e(route('admin.users.show', $user->id)); ?>"><?php echo e($user->name); ?></a> <br />
                                <?php if($user->email_verified_at): ?>
                                    <span class="badge badge-success">Verified</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Not Verified</span>
                                <?php endif; ?>
                                <br/>
                                <?php if($user->online): ?>
                                    <span class="badge badge-success">Online</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Offline</span>
                                <?php endif; ?>
                            </td>

                            <td width="10"><span style="font-size: 1.1em"> <?php echo e($user->email); ?></span> <br />


                                <?php if($user->hasRole('manager')): ?>
                                    <a href="<?php echo e(route('admin.assignUsers', $user->id)); ?>" class="btn btn-secondary"  data-placement="top" title="Assign Users"><em class="fa fa-plus"></em></a>
                                <?php endif; ?>

                                 <a href="<?php echo e(route('admin.user.gainaccess', $user->id)); ?>" onclick="alert('You are about to login as a Normal User that means you will be logged out as an admin on this browser')" target="_blank" class="btn btn-primary btn-small text-capitalize ">Login as <?php echo e($user->first_name); ?></a>







                            </td>
                                <td>
                                    <a  href="tel:<?php echo e($user->phone); ?>">
                                        {{showPhone(<?php echo $user->id; ?>)}}

                                        <?php if(auth()->user()->hasRole(['superadmin'])): ?>
                                            <a href="#" data-toggle="modal" data-target="#changePhone" v-on:click="setPhoneUpdateData(<?php echo e($user); ?>)"><i class="fa fa-edit"></i> </a>
                                        <?php endif; ?>
                                    </a>
                                    <br/>
                                    <?php if($user->country): ?>
                                        <?php echo e($user->country); ?> <em><sub><?php echo e($user->phone_code); ?></sub></em>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-outline-primary dropdown-toggle full-width" data-toggle="dropdown" data-toggle-position="left" aria-expanded="false">
                                            <?php if($user->statusrecord): ?> <?php echo e($user->statusrecord->name); ?> <?php else: ?> NA  <?php endif; ?>
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-right">
                                            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a class="dropdown-item" href="<?php echo e(route('admin.set.status',[$status->id, $user->id])); ?>"><?php echo e($status->name); ?></a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div> <br/>

                                    <a href="#" data-toggle="modal" data-target="#notes" v-on:click="createNote(<?php echo e($user); ?>)">Notes ({{ noteCount(<?php echo $user->id; ?>) }})</a>


                                </td>


                                <td class="text-capitalize"><?php if($user->manager_id > 0): ?> <?php echo e($user->manager->name); ?> <?php else: ?> NA <?php endif; ?></td>

                                <?php if(setting('invest')): ?>
                            <td><?php echo e($user->invested()); ?></td>
                                <?php endif; ?>


                                <td>
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-outline-primary dropdown-toggle full-width" data-toggle="dropdown" data-toggle-position="left" aria-expanded="false">
                                            <?php if($user->sourcerecord): ?> <?php echo e($user->sourcerecord->name); ?> <?php else: ?> NA <?php endif; ?>
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-right">
                                            <?php $__currentLoopData = $sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $source): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a class="dropdown-item" href="<?php echo e(route('admin.set.source',[$source->id, $user->id])); ?>"><?php echo e($source->name); ?></a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                </td>

                                <?php if(auth()->user()->hasRole(['superadmin'])): ?>
                                <td width="40">
                                Open : <a href="<?php echo e(route('admin.trades.index')); ?>?user=<?php echo e($user->id); ?>" ><?php echo e(\App\Models\Trade::whereUserId($user->id)->whereStatus(0)->count()); ?></a>
                                <br/>
                                Closed : <a href="<?php echo e(route('admin.trades.index')); ?>?user=<?php echo e($user->id); ?>" ><?php echo e(\App\Models\Trade::whereUserId($user->id)->whereStatus(1)->count()); ?></a>
                            <?php endif; ?>
                            </td>
                            <td>
                                <?php if(auth()->user()->hasRole(['superadmin'])): ?>
                                <span>Bal :  <?php echo e(amt($user->balance)); ?></span> <br/>
                                <span>Bonus :  <?php echo e(amt($user->bonus)); ?></span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($user->created_at); ?></td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="9" class="text-center">
                            <i>No Record Found!</i>
                        </td>
                    </tr>
                    <?php endif; ?>

                </tbody>
                </table>


                <div class="d-felx justify-content-center">

                    <?php echo e($users->links()); ?>


                </div>
            </div><!-- table-wrapper -->
            

            <div class="modal fade" id="bulkAction">
                <div class="modal-dialog modal-lg">
                  <div class="modal-content container">

                    <!-- Modal Header -->
                    <div class="modal-header">
                      <h4 class="modal-title">Bulk Action</h4>
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>

                    <!-- Modal body -->
                    <form  @submit.prevent="submitBulkAction">
                        <div class="modal-body">
                                <div class="row">
                                    <div class="form-group form-check col-12">
                                      <label class="form-check-label">
                                        <input class="form-check-input" type="checkbox" v-model="bulkAction.delete"> Mass Delete
                                      </label>
                                    </div>
                                </div>
                                <div class="row" v-show="bulkAction.delete">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <input id="password" class="form-control" type="password" placeholder="Enter Admin Password" v-model="bulkAction.admin_password" autofocus>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group form-check">
                                    <label class="form-check-label">
                                      <input class="form-check-input" type="checkbox" v-model="bulkAction.convertTo"> Revert to lead
                                    </label>
                                  </div>
                                </div>

                                <!-- Modal footer -->
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary" :disabled="isLoading">Confirm <i class="fa fa-spinner fa-spin" aria-hidden="true" v-if="isLoading"></i></button>
                            </div>
                    </form>
                  </div>
                </div>
              </div>

              <div class="modal fade modal-xl" id="accessTokenModal" tabindex="-1" role="dialog" aria-labelledby="accessTokenModal" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLongTitle">Access Token</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    
                  </div>
                </div>
              </div>

            <div class="modal fade" id="changePhone" tabindex="0" aria-labelledby="changePhone" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <div class="modal-dialog modal-md">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="confirmationLabel text-capitalise">Update {{ updatePhoneData.name }} Phone</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form action="#" @submit.prevent="updatePhone">
                            <div class="modal-body">
                                <div class="row">
                                        <div v-if="errors" class="col-12">
                                            <ul class="alert alert-danger">
                                                <li class="alert alert-danger" v-for="(value, key, index) in validationErrors">{{ value }}</li>
                                            </ul>
                                        </div>
                                        <div v-if="phoneUpdateSuccess" class=" col-12 alert alert-success">
                                            Phone Updated successfully!
                                        </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="row">
                                            <label class="col-sm-12 form-control-label">Phone Number: <span class="tx-danger">*</span></label>
                                            <div class="col-sm-12">
                                                <input type="text" placeholder="Phone" class="form-control" v-model="updatePhoneData.phone" required>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-sm btn-default" data-dismiss="modal">Done</button>
                                <button type="submit" class="btn btn-sm btn-primary" id="submitBtn" :disabled="isLoading">Update <i class="fa fa-spinner fa-spin" aria-hidden="true" v-if="isLoading"></i></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="confirmation" tabindex="0" aria-labelledby="confirmationLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <div class="modal-dialog modal-sm">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="confirmationLabel">Authentication</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                        <form action="" onsubmit="return false" autocomplete="new-password">
                            <div class="form-group">
                                <label for="password" class="col-form-label">Please enter your password to confirm</label>
                                <input type="password" class="form-control" id="password" autocomplete="new-password">
                                <small id="passwordHelp" class="form-text  text-danger">There is no reversal to this! Are you sure you want to remove this user entirely from the system?</small>
                              </div>
                        </form>

                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Cancel</button>
                      <button type="button" class="btn btn-sm btn-danger" id="submitBtn"  >Delete</button>
                    </div>
                  </div>
                </div>
            </div>

            <div class="modal fade" id="notes" tabindex="0" aria-labelledby="Notes" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="confirmationLabel">Notes - {{newNote.user}}<h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form action="#" @submit.prevent="addNote">
                            <div class="modal-body">
                                <div class="row">
                                    <div v-if="errors" class="col-12">
                                        <ul class="alert alert-danger">
                                            <li class="alert alert-danger" v-for="(value, key, index) in validationErrors">{{ value }}</li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12 mg-t-20">
                                        <label class="col-sm-12 form-control-label">Note:</label>
                                        <div class="col-sm-12">
                                            <textarea class="form-control" placeholder="Note" v-model="newNote.content" required autocomplete="note"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-12 mg-t-20" v-if="newNote.contacted">
                                        <label class="col-sm-12 form-control-label">Date Contacted:</label>
                                        <div class="col-sm-12">
                                            <input  type="datetime-local" placeholder="Status Name" class="form-control" v-model="newNote.contacted_at" required autocomplete="name">
                                        </div>
                                    </div>
                                    <div class="col-12 mg-t-20">
                                        <div class="col-sm-12">
                                            <label><input  type="radio" v-bind:value=true v-model="newNote.contacted"> I have contacted this user</label><br>
                                            <label><input  type="radio" v-bind:value=false v-model="newNote.contacted"> I have NOT contacted this user</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Done</button>
                                <button type="submit" :disabled="addingNote" class="btn btn-sm btn-success">Add Note <i class="fa fa-spinner fa-spin" aria-hidden="true" v-if="addingNote"></i> </button>
                            </div>
                            <div class="col-12 mg-t-20 px-4" v-for="(note, index) in userNotes" :key="index">
                                <b>{{ note.writer_name ?? '' }}</b>
                                <p>{{ note.content }}<br> <small v-if="note.contacted_at">Contacted @ {{ note.contacted_at }}</small></p>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <?php echo $__env->make('admin.partials.dt-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        let generateAccessTokenUrl = "<?php echo e(route('backend.user.token.generate')); ?>";
        let bulkActionUrl = "<?php echo e(route('admin.users.bulkaction')); ?>";

        let saveUserUrl = "<?php echo e(route('admin.lead.store')); ?>";
        // let convert = "<?php echo e(route('admin.users.lead.convert')); ?>";
        let deleteCustomersUrl = "<?php echo e(route('admin.user.deleteMultiple')); ?>";
        let changeManagerUrl = "<?php echo e(route('admin.lead.updateManager')); ?>";
        let addNoteUrl = "<?php echo e(route('admin.lead.addNote')); ?>";
        let updatePhoneUrl = "<?php echo e(route('admin.lead.updatePhone')); ?>";

        document.addEventListener('DOMContentLoaded', function () {
            new Vue({
                el: '#vue-content',
                data() {
                    return {
                        fetchingAccessToken: false,
                        generatedAccessToken: '',
                        changingToCustomer: false,
                        changingManager: false,
                        copied: false, // if accessToken has been copied
                        bulkAction: {
                            delete: false,
                            convertTo: null,
                        },
                        selectAllUsers: false,
                        asset : '',
                        isLoading : false,
                        errors : null,
                        error : null,
                        form : {
                            password: '',
                            confirm: '',
                            user_id:'',
                        },
                        data : {
                            first_name : '',
                            source : '',
                            last_name : '',
                            email : '',
                            username : '',
                            manager_id : '',
                            country : ''
                        },
                        //
                        selected_users: [],
                        // note
                        newNote: {
                            user: '',
                            user_id: '',
                            content: '',
                            contacted_at: null,
                            contacted: true
                        },
                        changeManagerData: {
                            manager_id: '',
                        },
                        addingNote: false,
                        userNotes: [],
                        customers: <?php echo json_encode($users); ?>,

                        // phone update
                        updatePhoneData: {
                            phone: '',
                        },
                        phoneUpdateSuccess: false
                    }
                },
                mounted() {
                    // this.getAllTrades();
                    $('#datatable').DataTable({
                        iDisplayLength : 100,
                        responsive: true,
                        language: {
                            searchPlaceholder: 'Search...',
                            sSearch: '',
                            lengthMenu: '_MENU_ items/page',
                        }
                    });
                },
                methods: {
                    setManagerAs (id) {
                        if (!confirm('Are you sure you want to perform this actions')) return;
                        if (this.selected_users.length < 1) { alert('No User is selected'); return; }

                        this.changeManagerData.manager_id = id;
                        this.changeManagerData.selected_users = this.selected_users // attach the selected users
                        this.changingManager = true;
                        axios.post(changeManagerUrl, this.changeManagerData).then((res) => {
                            this.changingManager = false;
                            window.location.reload();
                        }).catch((error) => {
                            this.changingManager = false;
                            if (error.response.status === 422){
                                this.errors = error.response.data.errors;
                                // alert(error.response.data.errors[0]);
                            } else if (error.response.status === 500){
                                alert(error.response.data.message);
                            }
                        })
                    },
                    generateAccessToken(user_id) {
                        this.fetchingAccessToken = true;
                        this.error = null;
                        axios.post(generateAccessTokenUrl, {user_id}).then((res)=>{
                            this.fetchingAccessToken = false
                            // show modal with
                            this.generatedAccessToken = res.data

                        }).catch((error)=>{
                            this.fetchingAccessToken = false
                            if (errors.response) {
                                if (error.response.status === 422){
                                    this.errors = error.response.data.errors;
                                } else if (error.response.status === 500){
                                    alert(error.response.data.message);
                                } else {
                                    alert(errror.response.statusText);
                                }
                            }
                        })
                    },
                    // copyAccessToken(accessToken) {
                    //     navigator.clipboard.writeText(accessToken);
                    //     this.copied = true;
                    //     setTimeout(() => {
                    //         this.copied = false;
                    //     }, 2000);
                    // },
                    submitBulkAction() {
                        if (this.selected_users.length < 1) { alert('No User is selected'); return; }
                        if(!confirm('Are you sure you want to convert selected users to customer?')) return ;

                        if (this.bulkAction.convertTo) this.bulkAction.convertTo = 'lead'
                        this.bulkAction.selected_users = this.selected_users

                        this.isLoading = true;
                        this.error = null;
                        axios.post(bulkActionUrl, this.bulkAction).then((res)=>{
                            this.isLoading = false;
                            this.reg_success = true;
                            window.location.reload();
                        }).catch((error)=>{
                            this.isLoading = false
                            if (error.response.status === 422){
                                this.errors = error.response.data.errors;
                            } else if (error.response.status === 500){
                                alert(error.response.data.message);
                        }
                        })
                    },
                    setPhoneUpdateData(user) {
                        this.updatePhoneData.name = user.name
                        this.updatePhoneData.phone = user.phone;
                        this.updatePhoneData.user_id = user.id;
                    },
                    updatePhone() {
                        this.isLoading = true;
                        this.error = null;
                        this.phoneUpdateSuccess = false;
                        axios.post(updatePhoneUrl, this.updatePhoneData).then((res)=>{
                            this.isLoading = false;
                            this.customers.data.find((u) => u.id == res.data.id).phone = res.data.phone;
                            this.phoneUpdateSuccess = true;
                        }).catch((error)=>{
                            this.isLoading = false;
                            this.phoneUpdateSuccess = false;
                            if (error.response) {
                                if (error.response.status === 422){
                                    this.errors = error.response.data.errors;
                                } else if (error.response.status === 500){
                                    alert(error.response.data.message);
                                }
                            }
                        })
                    },

                    deleteCustomers() {
                        if (this.selected_users.length < 1) { alert('No User is selected'); return; }
                        if(!confirm('Are you sure you want to delete this customer?\nThis action CANNOT be reversed!')) return ;

                        console.log('fffff');
                            this.deletingCustomers = true;
                            this.error = null;
                            axios.post(deleteCustomersUrl, {selected_users: this.selected_users}).then((res)=>{
                                this.deletingCustomers = false;
                                window.location.reload();
                            }).catch((error)=>{
                                this.deletingCustomers = false
                                if (error.response.status === 422){
                                    this.errors = error.response.data.errors;
                                } else if (error.response.status === 500){
                                    alert(error.response.data.message);
                                }
                            })
                    },
                    noteCount(userId) {
                        return this.customers.data.find((user) => user.id == userId).notes.length;
                    },
                    showPhone(userId) {
                        return this.customers.data.find((user) => user.id == userId).phone;
                    },
                    createNote(user) {
                        this.newNote = {
                            user: user.name,
                            user_id: user.id,
                            content: '',
                            contacted_at: null,
                            contacted: true
                        }
                        this.userNotes = this.customers.data.find((u) => u.id == user.id).notes; // copy a reference of this users note
                    },
                    addNote() {
                        if (!this.newNote.contacted) {
                            this.newNote.contacted_at = null
                        }

                        this.addingNote = true;
                        axios.post(addNoteUrl, this.newNote).then((res) => {
                            this.addingNote = false;
                            console.log(res.data);
                            this.customers.data.find((u) => u.id == res.data.user_id).notes.unshift(res.data); // add to notes to increase count
                        }).catch((error) =>{
                            this.addingNote = false;
                            if (error.response.status === 422) {
                                this.errors = error.response.data.errors;
                            } else if (error.response.status === 500){
                                alert(error.response.data.message);
                            }
                        })
                    },
                    submitForm(){
                        this.isLoading = true;
                        this.errors = null;
                        this.reg_success = false;
                        axios.post(saveUserUrl, this.data).then((res)=>{
                            this.isLoading = false;
                            this.reg_success = true;
                            window.location.reload();
                        }).catch((error)=>{
                            this.isLoading = false
                            if (error.response.status === 422){
                                this.errors = error.response.data.errors;
                            }
                        })
                    },
                },

                computed: {
                    validationErrors(){
                        let errors = Object.values(this.errors);
                        errors = errors.flat();
                        return errors;
                    },

                },

                watch: {
                    selectAllUsers: function (newValue, oldValue) {
                        if (newValue > oldValue) {
                            this.selected_users = []
                            this.customers.forEach((user) => {
                                this.selected_users.push(user.id);
                            });
                        } else {
                            this.selected_users = []
                        }
                    }
                }
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u518791033/domains/web-terminal.online/public_html/resources/views/admin/users/customers.blade.php ENDPATH**/ ?>