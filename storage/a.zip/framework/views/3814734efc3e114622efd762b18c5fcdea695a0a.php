<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <!-- START: Breadcrumbs-->
        <div class="row ">
            <div class="col-12  align-self-center">
                <div class="sub-header mt-3 py-3 px-3 align-self-center d-sm-flex w-100 rounded">
                    <div class="w-sm-100 mr-auto"><h4 class="mb-0">Transaction History</h4></div>

                    <ol class="breadcrumb bg-transparent align-self-center m-0 p-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('backend.dashboard')); ?>"> Dashboard</a></li>
                        <li class="breadcrumb-item">Transaction History (<?php echo e(count($transactions)); ?></li>
                    </ol>
                </div>
            </div>
        </div>
        <!-- END: Breadcrumbs-->


        <div class="row">


            <div class="col-xl-12 col-lg-12 col-sm-12">

                <div style="margin-top: 10px" class="card">
                    <div class="card-header">
                        <h5 class="card-title">Your Transaction History</h5>
                    </div>
                    <div class="card-body">
                        <div class="transaction-table">
                            <div class="table-responsive">
                                <table id="datatable" class="display table dataTable table-striped table-bordered">
                                    <thead>
                                    <tr>
                                        <th></th>

                                        <th>Type</th>
                                        <th>Account</th>

                                        <th>Note</th>
                                        <th>Amount</th>

                                        <th>Date</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>

                                            <?php if($item->status): ?>
                                                <td><span class="buy-thumb"><i class="fa fa-arrow-up"></i></span>
                                                </td>
                                            <?php else: ?>
                                                <td><span class="sold-thumb"><i class="fa fa-arrow-down"></i></span>
                                                </td>
                                            <?php endif; ?>


                                            <td>
                                                <span class="badge <?php echo e($item->status ? 'badge-success' : 'badge-danger'); ?> p-2"><?php echo e($item->type); ?></span>
                                            </td>
                                            <td>
                                                <i class="cc BTC"></i> <?php echo e($item->account_type); ?>

                                            </td>

                                            <td class="">
                                                <?php echo e($item->note); ?>

                                            </td>
                                            <td class="<?php echo e($item->account_type == 'withdrawal' ? 'text-danger' : 'text-success'); ?>"><?php echo e($item->amount); ?> USD</td>

                                            <td><?php echo e($item->created_at); ?></td>
                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </div>


    <?php echo $__env->make('partials.datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('backend.layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u518791033/domains/web-terminal.online/public_html/resources/views/backend/transactions.blade.php ENDPATH**/ ?>