f<!-- START: Header-->
<div id="header-fix" class="header fixed-top">
    <nav class="navbar navbar-expand-xl p-0">
        <div class="navbar-header h4 mb-0 align-self-center d-flex">
            <a href="#" class="sidebarCollapse ml-2 d-lg-none" id="collapse"><i
                    class="icon-menu body-color"></i></a>
            
            
            
        </div>

        <div class="d-inline-block position-relative">
            <button data-toggle="modal" data-target=".bd-example-modal-lg"
                class="btn btn-primary p-2  mx-3 h6 mb-0 line-height-1 d-none d-lg-block">
                <span class="text-white font-weight-bold h6">DEPOSIT</span>
            </button>
        </div>

        <!-- START: Logo-->
        <a href="<?php echo e(env('SITE_URL')); ?>" class="sidebar-logo d-flex ml-3">
        <img src="<?php echo e(setting('logo','/asset/images/logosm.png')); ?>" alt="logo" width="70" class="m-1 p-0 img-fluid main-logo"/>
        
        </a>
        
        <!-- END: Logo-->
        <div class="row crypto-row align-items-center pr-3 pl-2 ml-0">
            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="asset-item">
                    
                    <a href="#" data-toggle="modal" data-target="#show<?php echo e($i); ?>">
                        
                        
                        <?php echo e($i); ?> &nbsp;
                        <i class="fa fa-angle-down hidden-sm"
                           style="color: rgba(255, 255, 255, 0.7; font-weight: 600;"></i>
                    </a>
                </div>

                <div class="modal fade" id="show<?php echo e($i); ?>" tabindex="-1" role="dialog"
                     aria-labelledby="exampleModalLongTitle1" aria-hidden="true">
                    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">

                        <?php
                            $assets = \App\Models\CurrencyPair::where('rate', '!=', 0.0)
                                ->where('type', $i)
                                ->where('disabled', 0)
                                ->get();
                        ?>

                        <all_assets tradestation="<?php echo e(route('backend.tradestation')); ?>" :key="<?php echo e($i); ?>" id="<?php echo e($i); ?>" i="<?php echo e($i); ?>"
                                    :asset='<?php echo json_encode($assets, 15, 512) ?>'></all_assets>

                    </div>


                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>


        <form class="float-left d-none d-lg-block search-form">
            <div class="form-group mb-0 position-relative">
                <input type="text" class="form-control border-0 rounded bg-search pl-5"
                    placeholder="Search anything...">
                <div class="btn-search position-absolute top-0">
                    <a href="#"><i class="h5 icon-magnifier body-color"></i></a>
                </div>
                <a href="#" class="position-absolute close-button mobilesearch d-lg-none" data-toggle="dropdown"
                    aria-expanded="false"><i class="icon-close h5"></i>
                </a>

            </div>
        </form>

        <div class="dropdown d-sm-none d-md-none d-lg-none">
            <a href="#" aria-expanded="false" data-toggle="modal" data-target=".bd-example-modal-lg">
                <h5 class="ml-3 mb-0" style="color: #27B254; font-weight: bold; font-family:'Trebuchet MS';">
                    <?php echo e(amt(auth()->user()->balance)); ?></h5>
            </a>
            <div class="dropdown-menu">
                <a href="#" class="dropdown-item px-2 align-self-center d-flex d-md-none d-lg-none" data-toggle="modal"
                    data-target=".bd-example-modal-lg">
                    Deposit
                </a>
            </div>
        </div>

        <div class="navbar-right ml-auto">
            <ul class="ml-auto p-0 m-0 list-unstyled d-flex align-items-center">
                <!-- <li class="dropdown hidden-sm">
                    <a
                        href="#"
                        class="nav-link px-2 ml-3 mb-0"
                        data-toggle="dropdown"
                        aria-expanded="false"
                        style="color: #27B254; font-weight: bold; font-size: 1.25rem;"
                    >
                        
                        <i class="fa fa-angle-down" style="color: #215f4e; font-weight: 600;"></i>
                    </a>

                    <ul class="dropdown-menu dropdown-menu-right border py-0">
                        <li><a class="dropdown-item text-center py-2" href="<?php echo e(route('backend.deposits.index')); ?>">Deposit</a></li>
                        <li><a class="dropdown-item text-center py-2" href="<?php echo e(route('backend.withdraw.select')); ?>">Withdrawal</a></li>
                    </ul>
                </li> -->

                    <?php if(auth()->guard()->check()): ?>
                        <?php if(auth()->user()->hasRole(['admin','superadmin','manager', 'retention'])): ?>
                            <li class="hidden-sm">
                                <a target="_blank" href="<?php echo e(route('admin.dashboard')); ?>"
                                   class="btn btn-warning   mx-3 h6 mb-0 line-height-1 text-black-50" style="padding: 10px 20px; font-weight: bold">
                                    Switch to CRM
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php if(setting('kyc_verify_button') && auth()->user()->identity->status != 'approved'): ?>
                    <li class="hidden-sm">
                        <a href="<?php echo e(route('backend.profile.upload.id')); ?>"
                            class="btn btn-outline-danger text-white mx-3 h6 mb-0 line-height-1" style="padding: 10px 20px;">
                            <?php if(!auth()->user()->identity->front && auth()->user()->identity->status == 'pending'): ?>
                                Verify Your Account
                            <?php elseif(auth()->user()->identity->status == 'pending'): ?>
                                Pending Approval
                            <?php elseif(auth()->user()->identity->status == 'disapproved'): ?>
                                DISAPPROVED!
                            <?php endif; ?>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if(setting('autotrader')): ?>
                    <li class="hidden-sm">

                        <?php if(auth()->user()->trader_request == 'accepted' && auth()->user()->manager_id): ?>
                            <a href="<?php echo e(route('backend.profile.view', auth()->user()->manager_id)); ?>"
                                class="btn text-white btn-primary btn-deposit mx-3 h6 mb-0 line-height-1"
                                style="padding: 10px 20px;">
                                <i class="fa fa-user"></i> &nbsp; <?php echo e(auth()->user()->account_officer); ?>

                            </a>
                        <?php else: ?>
                            <button class="btn btn-primary btn-deposit mx-3 h6 mb-0 line-height-1"
                                style="padding: 10px 20px;">
                                <i class="fa fa-user"></i> &nbsp; <?php echo e(auth()->user()->account_officer); ?>

                            </button>
                        <?php endif; ?>
                    </li>
                <?php endif; ?>




                <li class="dropdown align-self-center mr-1 d-inline-block">
                    <a href="#" class="nav-link px-2" data-toggle="dropdown" aria-expanded="false"><i
                            class="icon-bell h4"></i>
                        
                    </a>
                    <ul class="dropdown-menu dropdown-menu-right border   py-0">
                        <li><a class="dropdown-item text-center py-2" href="#"> <strong>No Notification </strong></a>
                        </li>
                    </ul>
                </li>
                <li class="dropdown user-profile d-inline-block py-1 mr-2">
                    <a href="#" class="nav-link px-2 py-0" data-toggle="dropdown" aria-expanded="false">
                        <div class="media">
                            <div class="media-body align-self-center d-none d-sm-block mr-2">
                                <p class="mb-0 text-uppercase line-height-1 text-capitalize">
                                    <b><?php echo e(auth()->user()->first_name); ?></b><br /><span> </span></p>

                            </div>
                            <img src="<?php echo e(auth()->user()->avatar); ?>" alt="" class="d-flex img-fluid rounded-circle"
                                width="45">

                        </div>
                    </a>

                    <div class="dropdown-menu  dropdown-menu-right p-0">
                        <a href="<?php echo e(route('backend.withdraw.select')); ?>"
                            class="dropdown-item px-2 align-self-center d-flex">
                            <span class="icon-minus mr-2 h6 mb-0"></span> Withdraw</a>

                        <!--<a href="<?php echo e(route('backend.profile.edit')); ?>"-->
                        <!--    class="dropdown-item px-2 align-self-center d-flex">-->
                        <!--    <span class="icon-pencil mr-2 h6 mb-0"></span> Edit Profile</a>-->

                        <a href="<?php echo e(route('backend.profile.edit')); ?>"
                            class="dropdown-item px-2 align-self-center d-flex">
                            <span class="icon-pencil mr-2 h6 mb-0"></span> Edit Profile</a>
                        <a href="<?php echo e(route('backend.account.overview')); ?>"
                            class="dropdown-item px-2 align-self-center d-flex">
                            <span class="icon-user mr-2 h6 mb-0"></span> View Profile</a>
                        <div class="dropdown-divider"></div>
                        <a href="#" class="dropdown-item px-2 align-self-center d-flex d-md-none d-lg-none"
                            data-toggle="modal" data-target=".bd-example-modal-lg">
                            Deposit
                        </a>
                       <!-- <a href="<?php echo e(setting('help_url', '#')); ?>" class="dropdown-item px-2 align-self-center d-flex">
                            <span class="icon-support mr-2 h6  mb-0"></span> Help Center</a>-->
                        <a href="<?php echo e(route('backend.account.security')); ?>"
                            class="dropdown-item px-2 align-self-center d-flex">
                            <span class="icon-settings mr-2 h6 mb-0"></span> KYC </a>
                        <a href="<?php echo e(route('backend.update_password')); ?>"
                            class="dropdown-item px-2 align-self-center d-flex">
                            <span class="icon-settings mr-2 h6 mb-0"></span> Change Password</a>
                        <div class="dropdown-divider"></div>

                        <a onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"
                            href="<?php echo e(route('logout')); ?>"
                            class="dropdown-item px-2 text-danger align-self-center d-flex">
                            <span class="icon-logout mr-2 h6  mb-0"></span> Sign Out
                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                            <?php if(isset($type)): ?>
                                <input type="text" hidden name="logoutType" id="logoutType" value="<?php echo e($type); ?>">
                                <input type="text" hidden name="adminID" id="adminID" value="<?php echo e($admin_id); ?>">
                            <?php endif; ?>
                        </form>
                    </div>

                </li>

                    <li class="hidden-sm text-success bal text-right" style="font-size: 1.5em; letter-spacing: 1.3px;">




                        <span class="bonus"> <span style="font-size: 0.9em; font-weight: lighter">Bonus</span> : <span class="bonus_fig"><?php echo e(amt(auth()->user()->bonus)); ?></span></span><br/>
                          <img src="<?php echo e(setting('site_logo')); ?>" />  <?php echo e(amt(auth()->user()->balance)); ?>


                    </li>

                    <li class="hidden-sm">
                        <button class="btn btn-primary mx-3 h6 mb-0 line-height-1" data-toggle="modal"
                                data-target=".bd-example-modal-lg" style="padding: 10px 20px;">
                            Deposit
                        </button>
                    </li>


            </ul>
        </div>
    </nav>
</div>
<!-- END: Header-->
<?php /**PATH /home/u518791033/domains/web-terminal.online/public_html/resources/views/partials/backend/header.blade.php ENDPATH**/ ?>