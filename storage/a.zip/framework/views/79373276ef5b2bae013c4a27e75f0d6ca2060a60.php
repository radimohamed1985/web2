<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="/dist/vendors/sweetalert/sweetalert.css">
<?php echo $__env->make('admin.partials.dt-css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>








<?php $__env->startSection('content'); ?>
    <div class="br-mainpanel br-profile-page">

        <div class="mx-3">
            <div class="mt-1 mb-1">
                <h3 class="text-center"><?php echo e($user->name); ?> => <?php echo e($user->email); ?></h3>
            </div>
            <div class="ht-50 bg-gray-100 d-flex align-items-center shadow-base ">
                <ul class="nav nav-outline active-info align-items-center flex-row mt-2" role="tablist">
                    <li class="nav-item active"><a class="nav-lin btn btn-dark active"  href="<?php echo e(route('admin.users.show', $user->id)); ?>">Profile</a></li>
                    <?php if(auth()->user()->hasRole(['superadmin'])): ?>
                    <?php endif; ?>
                    <?php if(auth()->user()->hasRole(['superadmin']) || auth()->user()->can_add_fund): ?>
                        <li class="nav-item"><a class="nav-lin btn btn-primary " data-toggle="tab" href="#posts" role="tab">Balance / Bonus</a></li>
                        <li class="nav-item"><a class="nav-lin  btn btn-success" data-toggle="tab" href="#photos" role="tab">Trades</a></li>

                    <?php endif; ?>
                    <?php if(auth()->user()->hasRole(['superadmin'])): ?>
                        <li class="nav-item"><a class="nav-lin btn btn-dark" data-toggle="tab" href="#trans" role="tab">Transactions</a></li>
                        <li class="nav-item"><a class="nav-lin btn btn-danger" data-toggle="tab" href="#withdrawals" role="tab">Withdrawals</a></li>
                    <?php endif; ?>
                   

                    <li class="nav-item">
                        <a data-toggle="tab" href="#activities" role="tab" class="btn btn-warning">Activities</a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.user.send-message-page',$user->id)); ?>" class="btn btn-danger ">Send Message</a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.user.gainaccess', $user->id)); ?>" onclick="alert('You are about to login as a Normal User that means you will be logged out as an admin on this browser')" target="_blank" class="btn btn-primary text-capitalize">Login as <?php echo e($user->first_name); ?></a>
                    </li>

                </ul>
            </div>

            <?php echo $__env->make('notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="mt-3 font-weight-bold" style="font-size: 20px;">
                <?php echo e($user->name); ?>

            </div>
            <div class="tab-content br-profile-body px-0 pb-2" style=" max-width: 100%!important; margin-top: -10px;">
                <div class="tab-pane fade active show" id="profile-details">

            <div class="d-flex  align-items-center">
                <!-- <div>
                    <button type="button" class="btn btn-danger mb-2" id="showActions" style="cursor: pointer;">Actions</button>
                </div> -->
                <div class="card pd-20 pd-xs-30 shadow-base bd-0 m-2" id="actions-details" style="display: none">
                    <div class="row btn-bloc">
                        
                        <a href="" class="btn btn-primary mb-2 ml-2">Edit Profile</a>
                        <a href="<?php echo e(route('admin.trades.index')); ?>?user=<?php echo e($user->id); ?>" class="btn btn-success mb-2 ml-2">Trade For <?php echo e($user->first_name); ?></a>
                        <?php if(auth()->user()->hasRole(['superadmin','admin']) || auth()->user()->can_add_fund): ?>
                        <a href="" data-toggle="modal" data-target="#fundBalance" class="btn btn-success mb-2 ml-2">Add / Substract Balance</a>
                        <?php endif; ?>
                        <a href="<?php echo e(route('admin.user.logins',$user->id)); ?>" class="btn btn-warning mb-2 ml-2">Login Logins</a>
                        <a href="<?php echo e(route('admin.user.logins',$user->id)); ?>" class="btn btn-danger mb-2 ml-2">Send Message</a>
                    </div>
                    <?php if(auth()->user()->hasRole(['superadmin','admin'])  || auth()->user()->can_add_fund): ?>
                    <div style="margin-top: 5px" class="row btn-bloc">
                        <a href="" data-toggle="modal" data-target="#fundBonus" class="btn btn-primary mb-2 ml-2">Add / Substract Bonus</a>

                        <?php if(auth()->user()->hasRole(['superadmin','admin'])): ?>

                        <a href="<?php echo e(route('admin.user.trade.toggle', $user->id)); ?>" class="btn  <?php echo e($user->can_trade ? 'btn-danger' : 'btn-success'); ?> mb-2 ml-2"><?php echo e($user->can_trade ? 'Disable' : 'Enable'); ?> Trade</a>

                        <a href="" data-toggle="modal" data-target="#planUpgrade" class="btn btn-primary mb-2 ml-2">Plan Upgrade</a>
                        
                        <a href="<?php echo e(route('admin.user.withdraw.toggle', $user->id)); ?>" class="btn <?php echo e($user->can_withdraw ? 'btn-danger' : 'btn-success'); ?> mb-2 ml-2"><?php echo e($user->can_withdraw ? 'Disable' : 'Enable'); ?> Withdraw</a>
                        <a href="" data-toggle="modal" data-target="#fundWithdrawable" class="btn btn-info mb-2 ml-2">Add Withdraw</a>
                        <a href="" data-toggle="modal" data-target="#setNotification" class="btn btn-success mb-2 ml-2">Notifications</a>
                            <?php endif; ?>
                    </div>
                    <?php endif; ?>
                    
                </div><!-- card -->
            </div>

                </div>
            </div>


            <div class="tab-content br-profile-body px-0 pb-2" style=" max-width: 100%!important;">
                
                <div class="tab-pane fade <?php echo e(request()->get('asset') ? ' ' : 'active show'); ?> " id="profile">
                    <div class="card shadow-base bd-0 rounded-0 widget-4">

                        <div class="card-body text-left">
                            <div class="d-flex align-items-center pb-4">
                                <?php if(setting('autotrader')): ?>
                                    <?php if($user->hasRole('user')): ?>
                                        <?php if(!$user->trader_request): ?>
                                            <div><a href="" data-toggle="modal" data-target="#connectTrader" class="btn btn-success mb-2">Send Autotrader request</a></div>
                                        <?php else: ?>
                                            <div><a href="#" class="btn btn-outline-success mb-2">Request : <?php echo e($user->trader_request); ?></a><div>
                                        <?php endif; ?>
                                            <?php if($user->manager_id): ?>
                                                <p><a href="<?php echo e(route('admin.trades.index')); ?>?user=<?php echo e($user->manager_id); ?>" class="btn  btn-outline-success"><?php echo e($user->account_officer); ?></a></p>
                                            <?php else: ?>
                                                <p><a href="#" class="btn  <?php echo e($user->manager_id ? 'btn-outline-success' : 'btn-outline-danger'); ?>"><?php echo e($user->account_officer); ?></a></p>
                                            <?php endif; ?>
                                    <?php endif; ?>
                                <?php endif; ?>

                                
                                
                                
                                <a class="btn btn-primary " href="<?php echo e(url('admin/users')); ?>" style="background-color:#00b297; border-color:#00b297;">Back</a>
                            </div>
                            <div class="row align-items-center">
                                <div class="col-lg-4 col-md-5">
                                    <a class="btn btn-primary " href="<?php echo e(url('admin/users')); ?>" style="background-color:#00b297; border-color:#00b297;"> << Back</a>

                                    <div class="d-flex align-items-center mb-3">

                                        <div class="card-profile-img">
                                            <img src="<?php echo e($user->avatar); ?>" alt="">
                                        </div><!-- card-profile-img -->
                                        <div class="ml-4">
                                            <h4 class="tx-bold tx-roboto tx-black tx-capitalize mb-1"><?php echo e($user->name); ?></h4>
                                            <p class="tx-dark mb-1"><?php echo e($user->email); ?></p>
                                            <p class="tx-dark mb-0">Current Plan : <?php echo e($user->plan); ?></p>
                                            <?php if(auth()->user()->hasRole(['superadmin'])): ?>
                                                <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="">Edit Profile</a><br/>
                                            <?php endif; ?>
                                            

                                            <?php if(auth()->user()->hasRole(['superadmin','admin'])): ?>
                                            <a href="" data-toggle="modal" data-target="#planUpgrade" class="btn btn-primary">Plan Upgrade</a>
                                            <?php endif; ?>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-8 col-md-7">
                                    <div class="row align-items-center">
                                        <div class="col-md-4">
                                            <div class="tx-center tx-sm-left">
                                                <p class="tx-black tx-bold mb-1">ESTIMATE BALANCE </p>
                                                <p class="mb-0" style="color: #29c359!important; font-size: 27px;"><?php echo e($user->balance()); ?></p>

                                                <p class="tx-black tx-bold mb-1">PNL BALANCE </p>
                                                <p class="mb-0" style="color: #29c359!important; font-size: 27px;"><?php echo e($user->pnl); ?></p>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="tx-center tx-sm-left">
                                                <p class="tx-black tx-bold mb-1">BONUS IN <span style="color: #ff7700;">USD</span></p>
                                                <p class="mb-0" style="color: #29c359!important; font-size: 27px;"><?php echo e($user->bonus); ?> USD</p>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div>
                                                <?php if(setting('autotrader')): ?>
                                                    <?php if($user->hasRole('user')): ?>
                                                        <?php if(!$user->trader_request): ?>
                                                            <div><a href="" data-toggle="modal" data-target="#connectTrader" class="btn btn-success mb-2">Send Autotrader request</a></div>
                                                        <?php else: ?>
                                                            <div><a href="#" class="btn btn-outline-success mb-2">Request : <?php echo e($user->trader_request); ?></a><div>
                                                        <?php endif; ?>
                                                            <?php if($user->manager_id): ?>
                                                                <p><a href="<?php echo e(route('admin.trades.index')); ?>?user=<?php echo e($user->manager_id); ?>" class="btn  btn-outline-success"><?php echo e($user->account_officer); ?></a></p>
                                                            <?php else: ?>
                                                                <p><a href="#" class="btn  <?php echo e($user->manager_id ? 'btn-outline-success' : 'btn-outline-danger'); ?>"><?php echo e($user->account_officer); ?></a></p>
                                                            <?php endif; ?>
                                                    <?php endif; ?>
                                                <?php endif; ?>

                                                
                                                
                                                
                                                <div>


                                                    <?php if(setting('auto_profit_lose') == 1): ?>
                                                        <?php if($autoPNL->status): ?>
                                                            <div class="alert alert-success">Auto Profit / Loss is currently running for this user</div>
                                                        <?php else: ?>
                                                            <div class="alert alert-danger">Auto Profit / Loss is disabled for this user</div>
                                                        <?php endif; ?>
                                                            <?php if(auth()->user()->hasRole(['superadmin','admin'])): ?>
                                                            <button type="button" class="btn btn-primary mb-2" data-toggle="modal" data-target="#autoPL" style="cursor: pointer;">Modify Auto P/L</button>
                                                                <?php endif; ?>
                                                    <?php endif; ?>

                                                        <?php if(auth()->user()->hasRole(['superadmin','admin'])): ?>
                                                            <a href="<?php echo e(route('admin.user.toggle', $user->id)); ?>" class="btn <?php echo e($user->is_active ? 'btn-danger' : 'btn-success'); ?>" data-toggle="tooltip" ><em class="fa <?php echo e($user->is_active ? 'fa-times ' : ' fa-check'); ?> "></em></a>
                                                        <?php endif; ?>
                    
                                                    <div class="card pd-20 pd-xs-30 shadow-base bd-0" id="actions-details" style="display: none;">
                                                        <div class="row btn-bloc">
                                                            
                                                            <a href="" class="btn btn-primary mb-2">Edit Profile</a>
                                                            <a href="<?php echo e(route('admin.user.logins',$user->id)); ?>" class="btn btn-danger mb-2">Send Message</a>
                                                            <a href="" data-toggle="modal" data-target="#fundBalance" class="btn btn-success mb-2">Add / Substract Fund</a>
                        
                                                        </div>
                                                            <div style="margin-top: 5px" class="row btn-bloc">
                                                            <a href="<?php echo e(route('admin.trades.index')); ?>?user=<?php echo e($user->id); ?>" class="btn btn-success mb-2">Trade For <?php echo e($user->first_name); ?></a>
                                                            <a href="<?php echo e(route('admin.user.trade.toggle', $user->id)); ?>" class="btn  <?php echo e($user->can_trade ? 'btn-danger' : 'btn-success'); ?> mb-2"><?php echo e($user->can_trade ? 'Disable' : 'Enable'); ?> Trade</a>
                                                            <a href="" data-toggle="modal" data-target="#planUpgrade" class="btn btn-primary mb-2">Plan Upgrade</a>
                                                            
                                                        </div>
                                                        
                                                    </div><!-- card -->
                                                </div>
                                                <a href="<?php echo e(route('admin.user.trade.toggle', $user->id)); ?>" class="btn  <?php echo e($user->can_trade ? 'btn-danger' : 'btn-success'); ?>"><?php echo e($user->can_trade ? 'Disable' : 'Enable'); ?> Trade</a>


                                                                </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <hr>
                            <div>
                                <div>
                                    <h6 class="tx-gray-800 tx-uppercase tx-semibold tx-13 mg-b-25">Profile Information</h6>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div>
                                                <div class="d-flex">
                                                    <div class="w-50">
                                                        <p class="tx-14 tx-capitalize tx-black tx-mont tx-spacing-1 mg-b-2">First Name</p>
                                                    </div>
                                                    <div class="w-50">
                                                        <p class="tx-info mg-b-25"><?php echo e($user->first_name); ?></p>
                                                    </div>
                                                </div>
                                                <div class="d-flex">
                                                    <div class="w-50">
                                                        <p class="tx-14 tx-capitalize tx-black tx-mont tx-spacing-1 mg-b-2">Last Name</p>
                                                    </div>
                                                    <div class="w-50">
                                                        <p class="tx-info mg-b-25"><?php echo e($user->last_name); ?></p>
                                                    </div>
                                                </div>
                                                <div class="d-flex">
                                                    <div class="w-50">

                                                        <p class="tx-14 tx-capitalize tx-black tx-mont tx-spacing-1 mg-b-2">Phone Number</p>
                                                    </div>
                                                    <div class="w-50">
                                                        <p class="tx-info mg-b-25"><a href="tel:<?php echo e($user->phone); ?>"> <?php echo e($user->phone_code); ?> <?php echo e($user->phone); ?></a></p>
                                                    </div>
                                                </div>

                                                <div class="d-flex">
                                                    <div class="w-50">
                                                        <p class="tx-14 tx-capitalize tx-black tx-mont tx-spacing-1 mg-b-2">Country</p>
                                                    </div>
                                                    <div class="w-50">
                                                        <p class="tx-info mg-b-25">  <image id="flag-icon" src="<?php echo e($user->iso); ?>" width="32" height="22" style="margin-right:4px; backgroud-color:#e9ecef;"/> <?php echo e($user->country); ?></p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div>
                                                <div class="d-flex">
                                                    <div class="w-50">
                                                        <p class="tx-14 tx-capitalize tx-black tx-mont tx-spacing-1 mg-b-2">Email Address</p>
                                                    </div>
                                                    <div class="w-50">
                                                        <p class="tx-inverse"><?php echo e($user->email); ?></p>
                                                    </div>
                                                </div>
                                                <div class="d-flex">
                                                    <div class="w-50">
                                                        <p class="tx-14 tx-capitalize tx-black tx-mont tx-spacing-1 mg-b-2">Present Address</p>
                                                    </div>
                                                    <div class="w-50">
                                                        <p class="tx-inverse mg-b-25"><?php echo e($user->address); ?> </p>
                                                    </div>
                                                </div>
                                                <div class="d-flex">
                                                    <div class="w-50">
                                                        <p class="tx-14 tx-capitalize tx-black tx-mont tx-spacing-1 mg-b-2">Permanent Address</p>
                                                    </div>
                                                    <div class="w-50">
                                                        <p class="tx-inverse mg-b-50"><?php echo e($user->permanent_address); ?></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <h3 class="tx-gray-800 tx-uppercase tx-semibold tx-13 mg-b-25">KYC Documents</h3>
                                    <?php if($user->identify): ?>
                                        <h3>Front</h3>
                                            <img height="100" width="100" src="<?php echo e($user->identify->front); ?>" />

                                        <h3>Back</h3>
                                        <img height="100" width="100" src="<?php echo e($user->identify->back); ?>" />

                                        <?php else: ?>
                                        <h6>Not Uploaded</h6>
                                    <?php endif; ?>

                                    <div class="text-center">

                           
                                        <?php if(auth()->user()->hasRole(['superadmin'])): ?>
                                           
                                            <a onclick="event.preventDefault();" data-delete="delete-form" href="<?php echo e(route('admin.user.delete', $user->id)); ?>" data-placement="top" class="btn btn-warning but_delete_action fa fa-trash but_delete_action" title="delete">
                                                <i class="fa fa-trash-alt"></i>
                                                Delete Account
                                            </a>
                                            <form id="delete-form" action="<?php echo e(route('admin.user.delete', $user->id)); ?>" method="POST" style="display: none;">
                                                <?php echo method_field('GET'); ?>
                                                <?php echo csrf_field(); ?>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                                    <?php if(setting('joint_account') == 1): ?>
                                    <hr>
                                    <div>
                                        <div>
                                            <h6 class="tx-gray-800 tx-uppercase tx-semibold tx-13 mg-b-25">Joint Account Information</h6>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div>

                                                        <div class="d-flex">
                                                            <div class="w-50">
                                                                <p class="tx-14 tx-capitalize tx-black tx-mont tx-spacing-1 mg-b-2">First Name</p>
                                                            </div>
                                                            <div class="w-50">
                                                                <p class="tx-info mg-b-25"><?php echo e($user->j_first_name); ?></p>
                                                            </div>
                                                        </div>
                                                        <div class="d-flex">
                                                            <div class="w-50">
                                                                <p class="tx-14 tx-capitalize tx-black tx-mont tx-spacing-1 mg-b-2">Last Name</p>
                                                            </div>
                                                            <div class="w-50">
                                                                <p class="tx-info mg-b-25"><?php echo e($user->j_last_name); ?></p>
                                                            </div>
                                                        </div>
                                                        <div class="d-flex">
                                                            <div class="w-50">
                                                                <p class="tx-14 tx-capitalize tx-black tx-mont tx-spacing-1 mg-b-2">Phone Number</p>
                                                            </div>
                                                            <div class="w-50">
                                                                <p class="tx-info mg-b-25"><?php echo e($user->j_phone); ?></p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div>
                                                        <div class="d-flex">
                                                            <div class="w-50">
                                                                <p class="tx-14 tx-capitalize tx-black tx-mont tx-spacing-1 mg-b-2">Email Address</p>
                                                            </div>
                                                            <div class="w-50">
                                                                <p class="tx-inverse"><?php echo e($user->j_email); ?></p>
                                                            </div>
                                                        </div>
                                                        <div class="d-flex">
                                                            <div class="w-50">
                                                                <p class="tx-14 tx-capitalize tx-black tx-mont tx-spacing-1 mg-b-2">Country</p>
                                                            </div>
                                                            <div class="w-50">
                                                                <p class="tx-inverse mg-b-25"><?php echo e($user->j_country); ?> </p>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                        </div><!-- card-body -->
                    </div><!-- card -->

                </div>





                <div class="tab-pane fade show" id="posts">
                    <div class="card pd-20 pd-xs-30 shadow-base bd-0 m-2" id="actions-details">
                        <div class="row btn-bloc">
                        <a href="" data-toggle="modal" data-target="#fundBonus" class="btn btn-primary mb-2 ml-2">Add / Substract Bonus</a>

                        <a href="" data-toggle="modal" data-target="#fundBalance" class="btn btn-success mb-2 ml-2">Add / Substract Balance</a>
                        </div>
                    </div>
                    <div class="card pd-20 pd-xs-30 shadow-base bd-0 mg-t-30">

                        <h3>All Deposits</h3>

                            <div class="table-wrapper">
                            <a href="<?php echo e(route('admin.users.deposits.create', $user)); ?>">
                                <button class="btn btn-primary mb-2 pull-right">Add Deposit</button>
                            </a>
                                <table class="datatable1 table table-bordered display responsive nowrap" style="width: 100%;">
                                    <thead>
                                    <tr>
                                        <th class="wd-5p">S/N</th>
                                        <th class="wd-15p">Action</th>
                                        <th class="wd-15p">Date</th>
                                        <th class="wd-15p">Deposited Amount</th>
                                        <th class="wd-10p">Proof</th>
                                        <th class="wd-10p">Status</th>
                                        
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php
                                        $count = 1;
                                    ?>
                                    <?php $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($count++); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('admin.users.deposits.edit', $item)); ?>" class="btn btn-primary" title="View User"><em class="fa fa-edit"></em></a>
                                            </td>
                                            
                                            <td><?php echo e($item->created_at->format('d-m-Y')); ?></td>
                                            <td><?php echo e(number_format($item->amount)); ?></td>
                                            <td>
                                                <?php if($item->proof): ?>
                                                    <a target="_blank" href="<?php echo e($item->proof); ?>">View Proof</a>
                                                <?php else: ?>
                                                    Not Uploaded
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                            <?php if($item->status): ?>
                                                <p class="badge badge-success">Approved</p>
                                                <?php else: ?>
                                                <p class="badge badge-danger">Pending</p>
                                                <?php endif; ?>
                                            </td>
                                            
                                            
                                            
                                            
                                            

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                        </div><!-- table-wrapper -->
                    </div>
                </div><!-- tab-pane -->

                <div class="tab-pane fade show" id="login">

                    <div class="card pd-20 pd-xs-30 shadow-base bd-0 mg-t-30">

                        <h3>All Activities</h3>


                                <div class="table-wrapper">
                                    <table id="datatable1" class="table display table-bordered responsive nowrap">
                                        <thead>
                                        <tr>
                                            <th class="wd-10p">S/N</th>
                                            <th  class="wd-15p">Ip Address</th>
                                            <th width="45%" class="wd-45p">Device Details</th>
                                            <th class="wd-15p">Login DateTime </th>
                                            <th class="wd-15p">Logout DateTime&nbsp; </th>
                                        </tr>
                                        </thead>
                                        <tbody>

                                        <?php
                                            $count = 1;
                                        ?>
                                        <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($count++); ?></td>
                                                <td><?php echo e($item->ip_address); ?></td>
                                                <td width="40%"><?php echo e($item->user_agent); ?></td>
                                                <td><?php echo e($item->login_at); ?></td>
                                                <td><?php echo e($item->logout_at); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>
                                </div><!-- table-wrapper -->


                    </div>
                </div><!-- tab-pane -->

                <div class="tab-pane fade show" id="activities">



                    <div class="card pd-20 pd-xs-30 shadow-base bd-0 mg-t-30">

                        <div class="dropdown show">
                            <a class="btn btn-success dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Settings
                            </a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                            <a class="dropdown-item" href="<?php echo e(route('admin.activity.notifications.settings')); ?>">Activity Notification Settings</a>
                            <hr />
                            <a class="dropdown-item" href="<?php echo e(route('admin.settings.notifications')); ?>">Activity Notification Email</a>
                        </div>
                        </div>

                        <h3>All Activities</h3>



                                <div class="table-wrapper">
                                    <table id="datatable1" class="table display table-bordered responsive nowrap">
                                        <thead>
                                        <tr>
                                            <th class="wd-10p">S/N</th>
                                            <th  class="wd-15p">Action</th>
                                            <th  class="wd-50">Description </th>
                                            <th class="wd-15p"> DateTime </th>
                                        </tr>
                                        </thead>
                                        <tbody>

                                        <?php
                                            $count = 1;
                                        ?>
                                        <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($count++); ?></td>
                                                <td></td>
                                                <td width="40%"><?php echo e($item->user_agent); ?></td>
                                                <td><?php echo e($item->login_at); ?></td>
                    
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>
                                </div><!-- table-wrapper -->


                    </div>
                </div><!-- tab-pane -->

                <?php if(auth()->user()->hasRole(['superadmin'])): ?>
                    <div class="tab-pane fade show" id="trans">
                        <div class="row ">
                            <div class="col-md-12">
                                <div class="card pd-20 pd-xs-30 shadow-base bd-0 mg-t-30">

                                    <div class="tabl-wrapper table-responsive">

                                        <form action="<?php echo e(route('admin.users.transactions.delete')); ?>" method="POST" id="deleteTransactionForm">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button class="btn btn-danger mb-2 delete-multiple-transactions" style="display: none;">Delete Selected</button>
                                            <table class="datatable1 table display table-bordered responsive nowrap" style="width: 100%">
                                                <thead>
                                                <tr>
                                                    <th>&nbsp;</th>
                                                    <th>S/N</th>
                                                    <th class="wd-15p">Action</th>
                                                    <th class="wd-15p">Date / Time</th>
                                                    <th class="wd-15p">Amount</th>
                                                    <th class="wd-15p">Source</th>
                                                    <th class="wd-10p">Fund Type</th>
                                                    <th class="wd-10p">Account</th>
                                                    <th class="wd-40p">Description</th>
                                                    
                                                </tr>
                                                </thead>
                                                <tbody>

                                                <?php
                                                    $count = 1;
                                                ?>
                                                <?php $__currentLoopData = $trans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><center><input type="checkbox" name="delete_transaction_ids[]" value="<?php echo e($item->id); ?>" onchange="toggleTransactionToDelete(this)"></center></td>
                                                        <td><?php echo e($count++); ?></td>
                                                        <td>
                                                            <a href="<?php echo e(route('admin.users.transactions.edit', $item)); ?>" class="btn btn-primary" title="View User"><em class="fa fa-edit"></em></a>
                                                            <a href="#" onclick="deleteTransactions(<?php echo e($item->id); ?>)" class="btn btn-danger delete-transaction-btn" title="View User"><em class="fa fa-trash"></em></a>
                                                        </td>
                                                        <td><?php echo e($item->created_at); ?></td>
                                                        <td><?php echo e(amt($item->amount)); ?></td>
                                                        <td><?php echo e($item->source); ?></td>
                                                        <td><?php echo e($item->type); ?></td>
                                                        <td><?php echo e($item->account_type); ?></td>
                                                        <td><?php echo e($item->note); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </tbody>
                                        </table>
                                        <button class="btn btn-danger delete-multiple-transactions" style="display: none;">Delete Selected</button>
                                    </form>
                                    </div><!-- table-wrapper -->
                                </div>
                            </div>



                        </div><!-- row -->
                    </div><!-- tab-pane -->
                <?php endif; ?>
                



                <div class="tab-pane fade <?php echo e(request()->get('asset') ? 'active show' : ''); ?>" id="photos">

                    <?php $__env->startSection('hide'); ?>

                        <div class="card pd-20 pd-xs-30 shadow-base bd-0 m-2" id="actions-details">

                            <div class="row btn-bloc">
                                <a href="<?php echo e(route('admin.trades.index')); ?>?user=<?php echo e($user->id); ?>" class="btn btn-success mb-2 ml-2">Trade For <?php echo e($user->first_name); ?></a>

                                <a href="<?php echo e(route('admin.user.trade.toggle', $user->id)); ?>" class="btn  <?php echo e($user->can_trade ? 'btn-danger' : 'btn-success'); ?> mb-2 ml-2"><?php echo e($user->can_trade ? 'Disable' : 'Enable'); ?> Trade</a>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="table-wrapper">
                                    <div class="card pd-20 pd-xs-30 shadow-base bd-0 mg-t-30 table-responsive">
                                        <table class="table datatabl table-bordered table-condensed display responsive nowrap">

                                            <thead>
                                            <tr>
                                                <th>Opened at</th>
                                                <th>Currency / Asset</th>
                                                <th>Amount</th>
                                                <th>Qty</th>
                                                <th>Direction</th>
                                                <th>Status</th>
                                                <th>Result</th>
                                                <th>PNL</th>
                                                <th>Edit</th>
                                                
                                            </tr>
                                            </thead>
                                            <?php if(count($trades) < 1): ?>
                                                <tbody>
                                                <tr>
                                                    <td colspan="100%">No results found</td>
                                                </tr>
                                                </tbody>
                                            <?php else: ?>
                                                <tbody>
                                                <?php $__currentLoopData = $trades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($item->open_at); ?></td>
                                                        <td><?php echo e(optional($item->currency)->name); ?></td>
                                                        <td><?php echo e($item->traded_amount); ?> USD</td>
                                                        <td><?php echo e($item->qty); ?> <?php echo e(optional($item->currency)->sym); ?></td>

                                                        <td>
                                                            <?php if($item->trade_type == 'buy'): ?>
                                                                <span class="badge badge-success p-2">Buy</span>
                                                            <?php else: ?>
                                                                <span class="badge badge-warning p-2">Sell</span>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <?php if($item->status == 0): ?>
                                                                <span class="badge badge-warning p-2">Running</span>
                                                            <?php else: ?>
                                                                <span class="badge badge-danger p-2">Closed</span>
                                                            <?php endif; ?>
                                                        </td>
                                                        <?php if($item->status == 1): ?>
                                                            <td>
                                                                <?php if($item->result === 2): ?>
                                                                    <span class="badge badge-danger p-2">loss</span>
                                                                <?php elseif($item->result === 1): ?>
                                                                    <span class="badge badge-success p-2">Won</span>
                                                                <?php elseif($item->result === 3): ?>
                                                                    <span class="badge badge-warning p-2">Draw</span>
                                                                <?php endif; ?>
                                                            </td>
                                                        <?php else: ?>
                                                            <td>
                                                                <button @click="closeOrder(i.id)" class="btn btn-danger">Close Trade</button>
                                                            </td>
                                                        <?php endif; ?>
                                                        <td>
                                                            <?php if($item->profit): ?>
                                                                <?php echo e(amt($item->profit)); ?>

                                                            <?php else: ?>
                                                                <span class="badge badge-danger p-2">Running</span>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <?php if($item->status === 0): ?>
                                                                <a href="" data-toggle="modal" data-target="#editTrade<?php echo e($item->id); ?>" class="btn btn-primary">Edit</a>
                                                            <?php else: ?>
                                                                <a href="" disabled="" data-toggle="modal" class="btn btn-warning">Closed</a>
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            <?php endif; ?>

                                            <?php $__env->startSection('hide'); ?>
                                                <thead>
                                                <tr>
                                                    <th>Opened at</th>
                                                    <th>Currency / Asset</th>
                                                    <th>Amount</th>
                                                    <th>Qty</th>
                                                    <th>Opening Price</th>
                                                    <th>Closing Price</th>
                                                    <th>Direction</th>
                                                    <th>Status</th>
                                                    <th>Result</th>
                                                    <th></th>
                                                </tr>
                                                </thead>
                                                <?php if(count($trades) < 1): ?>
                                                    <tbody>
                                                    <tr>
                                                        <td colspan="100%">No results found</td>
                                                    </tr>
                                                    </tbody>
                                                <?php else: ?>
                                                    <tbody >
                                                    <?php $__currentLoopData = $trades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($i->open_at); ?></td>
                                                            <td><?php echo e(optional($i->currency)->name); ?></td>
                                                            <td><?php echo e($i->traded_amount); ?> USD</td>
                                                            <td><?php echo e($i->qty); ?> <?php echo e(optional($i->currency)->sym); ?></td>
                                                            <td><?php echo e($i->opening_price); ?>USD</td>
                                                            <td>
                                                                <?php if($i->closing_price): ?>
                                                                    <?php echo e($i->closing_price); ?> USD
                                                                <?php else: ?>
                                                                    <span class="badge badge-success p-2">Running</span>
                                                                <?php endif; ?>
                                                            </td>
                                                            <td>
                                                                <?php if($i->trade_type == 'buy'): ?>
                                                                    <span class="badge badge-success p-2">Buy</span>
                                                                <?php else: ?>
                                                                    <span v-else class="badge badge-warning p-2">Sell</span>
                                                                <?php endif; ?>
                                                            </td>
                                                            <td>
                                                                <?php if($i->status == 0): ?>
                                                                    <span class="badge badge-success p-2">Running</span>
                                                                <?php else: ?>
                                                                    <span class="badge badge-warning p-2">Closed</span>
                                                                <?php endif; ?>
                                                            </td>
                                                            <td>
                                                                <?php if($i->result == 2): ?>
                                                                    <span class="badge badge-danger p-2">loss</span>
                                                                <?php elseif($i->result == 1): ?>
                                                                    <span class="badge badge-success p-2">Won</span>
                                                                <?php else: ?>
                                                                    <span class="badge badge-warning p-2">Draw</span>
                                                                <?php endif; ?>
                                                            </td>
                                                            <td>
                                                                <?php if($i->status == 0): ?>
                                                                    <a  href="<?php echo e(route('trade.close', $i->id)); ?>" class="btn btn-danger">Close Trade</a>
                                                                <?php else: ?>
                                                                    <button class="btn btn-warning" disabled>Closed</button>
                                                                <?php endif; ?>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                <?php endif; ?>
                                            <?php $__env->stopSection(); ?>

                                        </table>
                                    </div>
                                </div><!-- table-wrapper -->
                            </div>
                        </div>
                    <?php $__env->stopSection(); ?>



                            <p>
                                <button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                                    Add New Trade
                                </button>

                                <a href="<?php echo e(route('admin.user.trade.toggle', $user->id)); ?>" class="btn  <?php echo e($user->can_trade ? 'btn-danger' : 'btn-success'); ?> mb-2 ml-2 float-right"><?php echo e($user->can_trade ? 'Disable' : 'Enable'); ?> Trade</a>

                            </p>

                            <div class="collapse <?php echo e(request()->get('asset') ? 'show' : ''); ?>" id="collapseExample">
                                <div class="br-section-wrapper">
                                    <h6 class="tx-gray-800 tx-uppercase tx-bold tx-14 mg-b-10">Add Trade [increase or decrease opening rate to alter profit]</h6>

                                    <form action="<?php echo e(route('admin.trades.store')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-layout form-layout-1">
                                            <div class="row mg-b-25">

                                                <input name="user_id" type="hidden" value="<?php echo e($user->id); ?>">

                                                <div class="col-md-3">
                                                    <div class="form-group mg-b-10-force">
                                                        <label class="form-control-label">Select Asset Type: <span class="tx-danger">*</span></label>
                                                        <select v-model="data.a_type" id="asset"  name="type" required class="form-control">
                                                            <?php $__currentLoopData = ['crypto','stocks','forex','indices','commodities']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option  value="<?php echo e($item); ?>"><?php echo e($item); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div><!-- col-8 -->
                                                <div class="col-md-3">
                                                    <div class="form-group mg-b-10-force">
                                                        <label class="form-control-label">Select Asset : <span class="tx-danger">*</span></label>
                                                        <select v-model="data.coin_id" id="asset" @change="updateStatus(data.coin_id)" name="coin_id" required class="form-control">
                                                            <?php $__currentLoopData = \App\Models\CurrencyPair::whereType($c_type)->where('rate','!=',0.0000)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div><!-- col-8 -->
                                                <div class="col-md-3">
                                                    <div class="form-group mg-b-10-force">
                                                        <label class="form-control-label text text-capitalize"> Opening Rate [{{ coinPrice }}]: <span class="tx-danger">*</span></label>
                                                        <input v-model="data.value" disabled class="form-control" min="1" step="any" :value="data.value" required type="number" name="value" placeholder="Asset Value">
                                                        <input v-model="data.value" :value="data.value" required type="hidden" name="value">
                                                    </div>
                                                </div><!-- col-8 -->

                                                <div class="col-md-3">
                                                    <div class="form-group mg-b-10-force">
                                                        <label class="form-control-label text text-capitalize">Traded Volume : <span class="tx-danger">*</span></label>
                                                        <input v-model="data.volume" class="form-control" step="any" required type="number" name="amt" placeholder="Traded Volume">
                                                    </div>
                                                </div>

                                                <div class="col-md-3">
                                                    <div class="form-group mg-b-10-force">
                                                        <label class="form-control-label text text-capitalize">Amount in USD : <span class="tx-danger">*</span></label>
                                                        <input v-model="data.amount"  class="form-control" step="any" required type="number" name="amount" placeholder="Traded Amount">
                                                    </div>
                                                </div>


                                                <div class="col-md-3">
                                                    <div class="form-group mg-b-10-force">
                                                        <label class="form-control-label text text-capitalize">Leverage : <span class="tx-danger">*</span></label>
                                                        <input v-model="data.leverage" disabled class="form-control" step="any" placeholder="leverage">
                                                    </div>
                                                </div>

                                                <div class="col-md-3">
                                                    <div class="form-group mg-b-10-force">
                                                        <label class="form-control-label">Trade Type: <span class="tx-danger">*</span></label>
                                                        <select id="type" required class="form-control" name="type">
                                                            <option value="buy">Buy</option>
                                                            <option value="sell">Sell</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group mg-b-10-force">
                                                        <label class="form-control-label">Take Profit: <span class="tx-danger">*</span></label>
                                                        <select v-model="data.is_take_profit" required class="form-control" name="is_take_profit">
                                                            <option value="1">Enable</option>
                                                            <option value="0">Disable</option>
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-md-3">
                                                    <div class="form-group mg-b-10-force">
                                                        <label class="form-control-label">Stop loss: <span class="tx-danger">*</span></label>
                                                        <select v-model="data.is_stop_loss" id="trade_type" required class="form-control" name="is_stop_loss">
                                                            <option value="1">Enable</option>
                                                            <option value="0">Disable</option>
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-md-3" v-if="data.is_take_profit > 0">
                                                    <div class="form-group mg-b-10-force">
                                                        <label class="form-control-label text text-capitalize">Take Profit : <span class="tx-danger">*</span></label>
                                                        <input v-model="data.take_profit" :value="data.take_profit" class="form-control" step="any" required type="number" name="take_profit" placeholder="Take Profit">
                                                    </div>
                                                </div>

                                                <div class="col-md-3" v-if="data.is_stop_loss > 0">
                                                    <div class="form-group mg-b-10-force">
                                                        <label class="form-control-label text text-capitalize">Stop loss : <span class="tx-danger">*</span></label>
                                                        <input :value="data.stop_loss" v-model="data.stop_loss" class="form-control" step="any" required type="number" name="stop_loss" placeholder="stop_loss">
                                                    </div>
                                                </div>






                                            </div><!-- row -->

                                            <div class="form-layout-footer">
                                                <button class="btn btn-primary" type="submit">Submit Trade</button>
                                            </div><!-- form-layout-footer -->
                                        </div><!-- form-layout -->
                                    </form>
                                </div><!-- br-section-wrapper -->
                            </div>


                        <div class="br-section-wrapper mb-2" v-if="all_trades.length > 0">
                            <h6 class="tx-gray-800 tx-uppercase tx-bold tx-14 mg-b-10"> Open Trades</h6>

                            <div class="table-wrapper" v-cloak>

                                <table class="table table-bordered table-condensed display responsive">
                                    <thead>
                                    <tr>
                                        <th>Opened at</th>
                                        <th>Currency / Asset</th>
                                        <th>Leverage</th>
                                        <th>Amount</th>
                                        <th>Opening Value</th>
                                        <th>Current Value</th>
                                        <th>Qty</th>
                                        <th>By Admin</th>
                                        <th>Direction</th>
                                        <th>Status</th>
                                        
                                        <th>PNL</th>
                                        <th>Edit</th>
                                        <th>Close</th>
                                        <th>Delete</th>
                                        
                                    </tr>
                                    </thead>

                                    <tbody>
                                    <tr v-for="item in all_trades">
                                        <td>{{ item.open_at }}</td>
                                        <td>{{ item.currency ? item.currency.name : '' }}</td>
                                        <td>{{ item.leverage }} </td>
                                        <td>{{ item.traded_amount }} USD</td>
                                        <td>{{ item.opening_price }} USD</td>
                                        <td>{{ item.closing_price }} USD</td>
                                        <td>{{ item.qty }} {{ item.currency ? item.currency.sym : '' }}</td>

                                        <td>
                                            <span v-if="item.by_admin" class="badge badge-success p-2">Yes</span>
                                            <span v-else  class="badge badge-warning p-2">No</span>
                                        </td>
                                        <td>
                                            <span v-if="item.trade_type === 'buy'" class="badge badge-success p-2">Buy</span>
                                            <span v-else  class="badge badge-warning p-2">Sell</span>
                                        </td>
                                        <td>
                                            <span v-if="item.status < 1" class="badge badge-warning p-2">Running</span>
                                            <span v-else class="badge badge-danger p-2">Closed</span>
                                        </td>

                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        <td>
                                            {{ item.profit }}
                                        </td>
                                        <td>

                                            <button v-if="item.status == 0"  @click="editTrade(item)" class="btn btn-primary">Edit</button>
                                            
                                            <a v-else href="" disabled="" data-toggle="modal" class="btn btn-warning">Closed</a>

                                        </td>
                                        <td>
                                            <a  :href="'/close/trade/'+item.id+'/trades'" class="btn btn-danger">Close</a>
                                        </td>
                                        <td class="text-center">
                                            

                                            

                                            <div class="btn-group justify-center" role="group">
                                                <a :href="'/admin/users/trades/'+item.id+'/delete'" class="btn btn-danger" title="Delete Job" onclick="return confirm(&quot;Click Ok to delete Record.&quot;)">
                                                    <span class="fa fa-trash" aria-hidden="true"></span>
                                                </a>
                                            </div>

                                        </td>
                                    </tr>
                                    </tbody>


                                </table>

                            </div><!-- table-wrapper -->


                        </div>


                        <div class="br-section-wrapper">
                            <h6 class="tx-gray-800 tx-uppercase tx-bold tx-14 mg-b-10"> Closed Trades</h6>




                            <div class="table-wrapper">
                                <form action="<?php echo e(route('admin.users.trades.delete')); ?>" method="POST" id="deleteTradeForm">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button class="btn btn-danger mb-2 delete-multiple-trades" style="display: none;">Delete Selected</button>
                                    <table id="datatable1" class="table table-bordered table-condensed display responsive">
                                        <thead>
                                        <tr>
                                            <th></th>
                                            <th>Opened at</th>
                                            <th>Currency / Asset</th>
                                            <th>Amount</th>
                                            <th>Opening Value</th>
                                            <th>Current Rate</th>
                                            <th>Qty</th>
                                            <th>Direction</th>
                                            <th>Status</th>
                                            
                                            <th>PNL</th>
                                            <th>Edit</th>
                                            <th>Delete</th>
                                            
                                        </tr>
                                        </thead>
                                        <?php if(count($trades) < 1): ?>
                                            <tbody>
                                            <tr>
                                                <td colspan="100%">No results found</td>
                                            </tr>
                                            </tbody>
                                        <?php else: ?>
                                            <tbody>
                                            <?php $__currentLoopData = $trades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><center><input type="checkbox" name="delete_trade_ids[]" value="<?php echo e($item->id); ?>" onchange="toggleTradeToDelete(this)"></center></td>
                                                    <td><?php echo e($item->open_at); ?></td>
                                                    <td><?php echo e(optional($item->currency)->name); ?></td>
                                                    <td><?php echo e($item->traded_amount); ?> USD</td>
                                                    <td><?php echo e($item->opening_price); ?> USD</td>
                                                    <td><?php echo e($item->closing_price); ?> USD</td>
                                                    <td><?php echo e($item->qty); ?> <?php echo e(optional($item->currency)->sym); ?></td>

                                                    <td>
                                                        <?php if($item->trade_type == 'buy'): ?>
                                                            <span class="badge badge-success p-2">Buy</span>
                                                        <?php else: ?>
                                                            <span class="badge badge-warning p-2">Sell</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($item->status == 0): ?>
                                                            <span class="badge badge-warning p-2">Running</span>
                                                        <?php else: ?>
                                                            <span class="badge badge-danger p-2">Closed</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    <td>
                                                        
                                                        <?php echo e(amt($item->profit)); ?>

                                                        
                                                        
                                                        
                                                    </td>
                                                    <td>
                                                        <?php if($item->status === 0): ?>
                                                            <a href="" data-toggle="modal" data-target="#editTrade<?php echo e($item->id); ?>" class="btn btn-primary">Edit</a>
                                                        <?php else: ?>
                                                            <a href="" disabled="" data-toggle="modal" class="btn btn-warning">Closed</a>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="text-center">
                                                        

                                                        <div class="btn-group justify-center" role="group">
                                                            <a href="<?php echo e(route('admin.users.trades.delete-one', $item->id)); ?>" class="btn btn-danger" title="Delete Job" onclick="return confirm(&quot;Click Ok to delete Record.&quot;)">
                                                                <span class="fa fa-trash" aria-hidden="true"></span>
                                                            </a>
                                                        </div>

                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        <?php endif; ?>


                                    </table>
                                </form>
                            </div><!-- table-wrapper -->

                            <?php $__currentLoopData = $p_trade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div id="editTrade<?php echo e($item->id); ?>" class="modal fade">
                                    <div class="modal-dialog modal-lg" role="document">
                                        <div class="modal-content tx-size-sm">
                                            <div class="modal-header pd-x-20">
                                                <h6 class="tx-14 mg-b-0 tx-uppercase tx-inverse tx-bold"> Modify trade opening rate to alter profit</h6>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <form action="<?php echo e(route('admin.user.updateTrade')); ?>" method="POST">

                                                <div class="modal-body pd-20">

                                                    <?php echo csrf_field(); ?>
                                                    <div class="form-layout form-layout-1">
                                                        <div class="row mg-b-25">

                                                            <input name="id" type="hidden" value="<?php echo e($item->id); ?>">

                                                            <div class="col-md-12">
                                                                <div class="form-group mg-b-10-force">
                                                                    <label class="form-control-label"> Current Opening Rate : [<?php echo e($item->opening_price); ?>]</label>
                                                                    <input  value="<?php echo e($item->opening_price); ?>" class="form-control" required type="number" step="any" name="opening_price" placeholder="opening_price">
                                                                </div>
                                                            </div><!-- col-8 -->
                                                            <div class="col-md-12">
                                                                <div class="form-group mg-b-10-force">
                                                                    <label class="form-control-label"> Current PNL: <span class="tx-danger">*</span></label>
                                                                    <input disabled value="<?php echo e($item->profit); ?>" class="form-control" required type="number" step="any" name="profit" placeholder="PNL">
                                                                </div>
                                                            </div><!-- col-8 -->
                                                        </div>
                                                    </div>

                                                </div><!-- modal-body -->
                                                <div class="modal-footer">
                                                    <button type="submit" class="btn btn-primary tx-size-xs">Save</button>
                                                    <button type="button" class="btn btn-secondary tx-size-xs" data-dismiss="modal">Close</button>
                                                </div>
                                            </form>

                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div id="editTrade" ref="modal" class="modal fade">
                                <div class="modal-dialog modal-lg" role="document">
                                    <div class="modal-content tx-size-sm">
                                        <div class="modal-header pd-x-20">
                                            <h6 class="tx-14 mg-b-0 tx-uppercase tx-inverse tx-bold"> Modify trade opening rate to alter profit</h6>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <form action="<?php echo e(route('admin.user.updateTrade')); ?>" method="POST">

                                            <div class="modal-body pd-20">

                                                <?php echo csrf_field(); ?>
                                                <div class="form-layout form-layout-1">
                                                    <div class="row mg-b-25" v-if="form">

                                                        <input name="id" type="hidden" :value="eId">

                                                        <div class="col-md-12">
                                                            <div class="form-group mg-b-10-force">
                                                                <label class="form-control-label"> Current Opening Rate : [{{ form.opening_price }}]</label>
                                                                <input v-model="eOP"  :value="eOP" class="form-control" required type="number" step="any" name="opening_price" placeholder="opening_price">
                                                            </div>
                                                        </div><!-- col-8 -->
                                                        
                                                        <div class="col-md-12">
                                                            <div class="form-group mg-b-10-force">
                                                                <label class="form-control-label"> Current PNL: <span class="tx-danger">*</span></label>
                                                                <input disabled v-model="form.profit" :value="form.profit" class="form-control" required type="number" step="any" name="profit" placeholder="PNL">
                                                                <em v-if="calculating">Calculating pnl .............</em>

                                                            </div>
                                                        </div><!-- col-8 -->
                                                    </div>
                                                </div>

                                            </div><!-- modal-body -->
                                            <div class="modal-footer">
                                                <button type="submit" class="btn btn-primary tx-size-xs">Save</button>
                                                <button type="button" class="btn btn-secondary tx-size-xs" data-dismiss="modal">Close</button>
                                            </div>
                                        </form>

                                    </div>
                                </div>
                            </div>


                        </div>






                </div><!-- tab-pane -->


                <?php if(auth()->user()->hasRole(['superadmin'])): ?>
                    <div class="tab-pane fade" id="withdrawals">
                        <div class="card pd-20 pd-xs-30 shadow-base bd-0 m-2" id="actions-details">
                            <div class="row btn-bloc">
                        <a href="<?php echo e(route('admin.user.withdraw.toggle', $user->id)); ?>" class="btn <?php echo e($user->can_withdraw ? 'btn-danger' : 'btn-success'); ?> mb-2"><?php echo e($user->can_withdraw ? 'Disable' : 'Enable'); ?> Withdraw</a>
                        <a href="" data-toggle="modal" data-target="#fundWithdrawable" class="btn btn-info mb-2">Add Withdraw</a>
                            </div>
                        </div>

                        <div class="col-md-12">
                                <div class="card pd-20 pd-xs-30 shadow-base bd-0 mg-t-30 ">
                                    <div class="table-wrapper table-responsive">

                                    <table class="table datatabl table-bordered table-condensed display responsive nowrap">
                                        <thead>
                                            <tr>
                                                
                                                
                                                <th class="wd-20p">Order Type / Item</th>
                                                <th class="wd-10p">Currency Pair</th>
                                                <th class="wd-10p"> Buy at</th>
                                                <th class="wd-10p">Sell at</th>
                                                <th class="wd-10p">Item Price</th>
                                                <th class="wd-10p">Opening Price</th>
                                                <th class="wd-10p">Closing Price</th>
                                                <th class="wd-10p">Profit</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $trades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                
                                                
                                                <td><?php echo e($trade->order_type); ?></td>
                                                <td><?php echo e($trade->currency_pair); ?></td>
                                                <td><?php echo e($trade->buy_at); ?></td>
                                                <td><?php echo e($trade->sell_at); ?></td>
                                                <td><?php echo e($trade->item_price); ?></td>
                                                <td><?php echo e($trade->opening_price); ?></td>
                                                <td><?php echo e($trade->closing_price); ?></td>
                                                <td><?php echo e($trade->profit); ?></td>

                                                
                                                
                                                
                                                

                                                
                                                
                                                
                                                
                                                

                                                

                                                
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div><!-- table-wrapper -->
                        </div><!-- row -->
                    </div><!-- tab-pane -->
                <?php endif; ?>

                
            </div><!-- br-pagebody -->

            <div id="setNotification" class="modal fade">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content tx-size-sm">
                        <div class="modal-header pd-x-20">
                            <h6 class="tx-14 mg-b-0 tx-uppercase tx-inverse tx-bold">Change Admin Notifications for <?php echo e($user->name); ?></h6>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form action="<?php echo e(route('admin.user.notifications')); ?>" method="POST">

                            <div class="modal-body pd-20">
                                <input name="user_id" type="hidden" value="<?php echo e($user->id); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-layout form-layout-1">
                                    <div class="form-check">
                                        <input class="form-check-input" name="admin_notifications[]" type="checkbox" value="login" id="login" <?php if(in_array('login', $user->admin_notifications)): ?> checked  <?php endif; ?>>
                                        <label class="form-check-label" for="login">
                                          Login
                                        </label>
                                      </div>
                                      <div class="form-check">
                                        <input class="form-check-input" name="admin_notifications[]" type="checkbox" value="open-trade" id="open-trade" <?php if(in_array('open-trade', $user->admin_notifications)): ?> checked  <?php endif; ?>>
                                        <label class="form-check-label" for="open-trade">
                                          open trade
                                        </label>
                                      </div>
                                      <div class="form-check">
                                        <input class="form-check-input" name="admin_notifications[]" type="checkbox" value="close-trade" id="close-trade" <?php if(in_array('close-trade', $user->admin_notifications)): ?> checked  <?php endif; ?>>
                                        <label class="form-check-label" for="close-trade">
                                          close trade
                                        </label>
                                      </div>
                                </div>

                            </div><!-- modal-body -->
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary tx-size-xs">Submit</button>
                                <button type="button" class="btn btn-secondary tx-size-xs" data-dismiss="modal">Close</button>
                            </div>
                        </form>

                    </div>
                </div><!-- modal-dialog -->
            </div><!-- modal -->

            <div id="fundWithdrawable" class="modal fade">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content tx-size-sm">
                        <div class="modal-header pd-x-20">
                            <h6 class="tx-14 mg-b-0 tx-uppercase tx-inverse tx-bold">Update  <?php echo e($user->name); ?> Withdrawable</h6>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form action="<?php echo e(route('admin.user.updatewithdrawable')); ?>" method="POST">

                            <div class="modal-body pd-20">

                                <?php echo csrf_field(); ?>
                                <div class="form-layout form-layout-1">
                                    <div class="row mg-b-25">

                                        <input name="user_id" type="hidden" value="<?php echo e($user->id); ?>">

                                        <div class="col-md-12">
                                            <div class="form-group mg-b-10-force">
                                                <label class="form-control-label"> Withdrawable Amount: <span class="tx-danger">*</span></label>
                                                <input value="<?php echo e($user->withdrawable); ?>" class="form-control" required type="number" step="any" name="withdrawable" placeholder="Amount">
                                            </div>
                                        </div><!-- col-8 -->
                                    </div>
                                </div>

                            </div><!-- modal-body -->
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary tx-size-xs">Submit</button>
                                <button type="button" class="btn btn-secondary tx-size-xs" data-dismiss="modal">Close</button>
                            </div>
                        </form>

                    </div>
                </div><!-- modal-dialog -->
            </div><!-- modal -->

            <div id="fundBalance" class="modal fade">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content tx-size-sm">
                        <div class="modal-header pd-x-20">
                            <h6 class="tx-14 mg-b-0 tx-uppercase tx-inverse tx-bold">Make Deposit / Subtract From Balance</h6>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form action="<?php echo e(route('admin.user.fundaccount')); ?>" method="POST">

                            <div class="modal-body pd-20">

                                <?php echo csrf_field(); ?>
                                <div class="form-layout form-layout-1">
                                    <div class="row mg-b-25">

                                        <input name="user_id" type="hidden" value="<?php echo e($user->id); ?>">
                

                                        <div class="col-md-6">
                                            <div class="form-group mg-b-10-force">
                                                <label class="form-control-label"> Fund Type: <span class="tx-danger">*</span></label>
                                                <select name="type" class="form-control" required>
                                                    <option value="deposit">Deposit</option>
                                                    <option value="bonus">Bonus</option>
                                                    <option value="withdrawal">Withdrawal</option>
                                                </select>
                                            </div>
                                        </div><!-- col-8 -->
                                        <div class="col-md-6">
                                            <div class="form-group mg-b-10-force">
                                                <label class="form-control-label"> Notify Use Via Email:</label>
                                                <select name="notify" class="form-control" required>
                                                    <option value="0">No</option>
                                                    <option value="1">Yes</option>
                                                </select>
                                            </div>
                                        </div><!-- col-8 -->
                                        <div class="col-md-6">
                                            <div class="form-group mg-b-10-force">
                                                <label class="form-control-label"> Amount: <span class="tx-danger">*</span></label>
                                                <input class="form-control" required type="number" step="any" name="amount" placeholder="Amount">
                                            </div>
                                        </div><!-- col-8 -->
                                        <div class="col-md-6">
                                            <div class="form-group mg-b-10-force">
                                                <label class="form-control-label"> Source: <span class="tx-danger">*</span></label>
                                                <input class="form-control" required type="text" name="source" placeholder="Source">
                                            </div>
                                        </div><!-- col-8 -->
                                        <div class="col-md-12">
                                            <div class="form-group mg-b-10-force">
                                                <label class="form-control-label"> Note [pls specify a note or default will be used] : <span class="tx-danger">*</span></label>
                                                <textarea class="form-control" type="text" name="note"></textarea>
                                            </div>
                                        </div><!-- col-8 -->
                                    </div>
                                </div>

                            </div><!-- modal-body -->
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary tx-size-xs">Submit</button>
                                <button type="button" class="btn btn-secondary tx-size-xs" data-dismiss="modal">Close</button>
                            </div>
                        </form>

                    </div>
                </div><!-- modal-dialog -->
            </div><!-- modal -->

            <div id="autoPL" class="modal fade">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content tx-size-sm">
                        <div class="modal-header pd-x-20">
                            <h6 class="tx-14 mg-b-0 tx-uppercase tx-inverse tx-bold">Set Auto P/L for <?php echo e($user->name); ?></h6>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form action="<?php echo e(route('admin.user.modify_autopnl')); ?>" method="POST">

                            <div class="modal-body pd-20">

                                <?php echo csrf_field(); ?>
                                <div class="form-layout form-layout-1">
                                    <div class="row mg-b-25">

                                        <input name="user_id" type="hidden" value="<?php echo e($user->id); ?>">
                

                                        <div class="col-md-6">
                                            <div class="form-group mg-b-10-force">
                                                <label class="form-control-label">Status: <span class="tx-danger">*</span></label>
                                                <select name="status" class="form-control" required>
                                                    <option <?php echo e($autoPNL->status == 1 ? 'selected' : ''); ?> value="1">Enable </option>
                                                    <option <?php echo e($autoPNL->status == 0 ? 'selected' : ''); ?> value="0">Disable</option>
                                                </select>
                                            </div>
                                        </div><!-- col-8 -->
                                        <div class="col-md-6">
                                            <div class="form-group mg-b-10-force">
                                                <label class="form-control-label">Profit / Loss</label>
                                                <select name="pnl" class="form-control" required>
                                                    <option <?php echo e($autoPNL->pnl == 1 ? 'selected' : ''); ?> value="1">Profit</option>
                                                    <option <?php echo e($autoPNL->pnl == 0 ? 'selected' : ''); ?> value="0">Loss</option>
                                                </select>
                                            </div>
                                        </div><!-- col-8 -->
                                        <div class="col-md-6">
                                            <div class="form-group mg-b-10-force">
                                                <label class="form-control-label">Interval Type</label>
                                                <select name="interval_type" class="form-control" required>
                                                    <option <?php echo e($autoPNL->interval_type == 'hour' ? 'selected' : ''); ?> value="hour">Hour</option>
                                                    <option <?php echo e($autoPNL->interval_type == 'day' ? 'selected' : ''); ?> value="day">Daily</option>
                                                    <option <?php echo e($autoPNL->interval_type == 'week' ? 'selected' : ''); ?> value="week">Weekly</option>
                                                    <option <?php echo e($autoPNL->interval_type == 'month' ? 'selected' : ''); ?> value="month">Monthly</option>
                                                </select>
                                            </div>
                                        </div><!-- col-8 -->
                                        <div class="col-md-6">
                                            <div class="form-group mg-b-10-force">
                                                <label class="form-control-label">Interval </label>
                                                <input class="form-control" value="<?php echo e($autoPNL->interval); ?>" required type="number" step="any" name="interval" placeholder="Interval">
                                            </div>
                                        </div><!-- col-8 -->
                                        <div class="col-md-6">
                                            <div class="form-group mg-b-10-force">
                                                <label class="form-control-label">Fixed / Percentage</label>
                                                <select name="fixed" class="form-control" required>
                                                    <option <?php echo e($autoPNL->fixed == 'fixed' ? 'selected' : ''); ?> value="fixed">Fixed</option>
                                                    <option <?php echo e($autoPNL->fixed == 'percent' ? 'selected' : ''); ?> value="percent">Balance Percent</option>
                                                </select>
                                            </div>
                                        </div><!-- col-8 -->
                                        <div class="col-md-6">
                                            <div class="form-group mg-b-10-force">
                                                <label class="form-control-label"> Amount: <span class="tx-danger">*</span></label>
                                                <input class="form-control" value="<?php echo e($autoPNL->amount); ?>" required type="number" step="any" name="amount" placeholder="Amount">
                                            </div>
                                        </div><!-- col-8 -->

                                        <div class="col-md-6">
                                            <div class="form-group mg-b-10-force">
                                                <label class="form-control-label">Record Activity</label>
                                                <select name="record" class="form-control" required>
                                                    <option <?php echo e($autoPNL->record == 1 ? 'selected' : ''); ?> value="1">Yes</option>
                                                    <option <?php echo e($autoPNL->record == 0 ? 'selected' : ''); ?> value="0">No</option>
                                                </select>
                                            </div>
                                        </div><!-- col-8 -->


                                    </div>
                                </div>

                            </div><!-- modal-body -->
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary tx-size-xs">Submit</button>
                                <button type="button" class="btn btn-secondary tx-size-xs" data-dismiss="modal">Close</button>
                            </div>
                        </form>

                    </div>
                </div><!-- modal-dialog -->
            </div><!-- modal -->

            <div id="fundBonus" class="modal fade">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content tx-size-sm">
                        <div class="modal-header pd-x-20">
                            <h6 class="tx-14 mg-b-0 tx-uppercase tx-inverse tx-bold">Add / Subtract <?php echo e($user->name); ?> Account Bonus</h6>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form action="<?php echo e(route('admin.user.fundbonus')); ?>" method="POST">

                            <div class="modal-body pd-20">

                                <?php echo csrf_field(); ?>
                                <div class="form-layout form-layout-1">
                                    <div class="row mg-b-25">

                                        <input name="account_type" type="hidden" value="bonus">
                                        <input name="user_id" type="hidden" value="<?php echo e($user->id); ?>">

                                        <div class="col-md-6">
                                            <div class="form-group mg-b-10-force">
                                                <label class="form-control-label"> Fund Type: <span class="tx-danger">*</span></label>
                                                <select name="type" class="form-control" required>
                                                    <option value="credit">Add Money</option>
                                                    <option value="debit">Subtract Money</option>
                                                </select>
                                            </div>
                                        </div><!-- col-8 -->
                                        <div class="col-md-6">
                                            <div class="form-group mg-b-10-force">
                                                <label class="form-control-label"> Amount: <span class="tx-danger">*</span></label>
                                                <input class="form-control" required type="number" step="any" name="amount" placeholder="Amount">
                                            </div>
                                        </div><!-- col-8 -->
                                        <div class="col-md-12">
                                            <div class="form-group mg-b-10-force">
                                                <label class="form-control-label"> Note : <span class="tx-danger">*</span></label>
                                                <textarea class="form-control" type="text" name="note"></textarea>
                                            </div>
                                        </div><!-- col-8 -->
                                    </div>
                                </div>

                            </div><!-- modal-body -->
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary tx-size-xs">Submit</button>
                                <button type="button" class="btn btn-secondary tx-size-xs" data-dismiss="modal">Close</button>
                            </div>
                        </form>

                    </div>
                </div><!-- modal-dialog -->
            </div><!-- modal -->

            <div id="planUpgrade" class="modal fade">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content tx-size-sm">
                        <div class="modal-header pd-x-20">
                            <h6 class="tx-14 mg-b-0 tx-uppercase tx-inverse tx-bold">Upgrade <?php echo e($user->name); ?> Account Plan</h6>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form action="<?php echo e(route('admin.user.upgradeplan')); ?>" method="POST">
                            <div class="modal-body pd-20">
                                <?php echo csrf_field(); ?>
                                <div class="form-layout form-layout-1">
                                    <div class="row mg-b-25">

                                        <input name="user_id" type="hidden" value="<?php echo e($user->id); ?>">

                                        <div class="col-md-12">
                                            <div class="form-group mg-b-10-force">
                                                <label class="form-control-label"> Current Plan : <span class="tx-danger">*</span></label>
                                                <input class="form-control" type="text" value="<?php echo e($user->plan); ?>" disabled>
                                            </div>
                                        </div><!-- col-8 -->

                                        <div class="col-md-12">
                                            <div class="form-group mg-b-10-force">
                                                <label class="form-control-label"> Select Plan: <span class="tx-danger">*</span></label>
                                                <select name="plan" class="form-control" required>
                                                    <?php $__currentLoopData = \App\Models\Package::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div><!-- col-8 -->



                                    </div>
                                </div>

                            </div><!-- modal-body -->
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary tx-size-xs">Submit</button>
                                <button type="button" class="btn btn-secondary tx-size-xs" data-dismiss="modal">Close</button>
                            </div>
                        </form>

                    </div>
                </div><!-- modal-dialog -->
            </div><!-- modal -->

            <div id="connectTrader" class="modal fade">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content tx-size-sm">
                        <div class="modal-header pd-x-20">
                            <h6 class="tx-14 mg-b-0 tx-uppercase tx-inverse tx-bold">Send <?php echo e($user->name); ?> Autotrader request</h6>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form action="<?php echo e(route('admin.connect.account')); ?>" method="POST">
                            <div class="modal-body pd-20">
                                <?php echo csrf_field(); ?>
                                <div class="form-layout form-layout-1">
                                    <div class="row mg-b-25">

                                        <input name="user_id" type="hidden" value="<?php echo e($user->id); ?>">

                                        <div class="col-md-12">
                                            <div class="form-group mg-b-10-force">
                                                <label class="form-control-label"> Select Autotraders: <span class="tx-danger">*</span></label>
                                                <select name="trader_id" class="form-control" required>
                                                    <?php $__currentLoopData = \App\Models\User::whereRoleIs('autotrader')->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div><!-- col-8 -->
                                        <div class="col-md-12">
                                            <div class="form-group mg-b-10-force">
                                                <label class="form-control-label"> Send Email to user: <span class="tx-danger">*</span></label>
                                                <select name="sendmail" class="form-control" required>
                                                    <option value="0">No</option>
                                                    <option value="1">Yes</option>
                                                </select>
                                            </div>
                                        </div><!-- col-8 -->

                                        <div class="col-md-12">
                                            <div class="form-group mg-b-10-force">
                                                <label class="form-control-label"> Message [change admin to auto trader name] : <span class="tx-danger">*</span></label>
                                                <textarea class="form-control" type="text" name="message">Admin is trying to connect to your account, approve to grant access, once you accept this, Admin will trade on your behave</textarea>
                                            </div>
                                        </div><!-- col-8 -->

                                    </div>
                                </div>

                            </div><!-- modal-body -->
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary tx-size-xs">Send </button>
                                <button type="button" class="btn btn-secondary tx-size-xs" data-dismiss="modal">Close</button>
                            </div>
                        </form>

                    </div>
                </div><!-- modal-dialog -->
            </div><!-- modal -->


            <?php $__currentLoopData = $trades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="editTrade<?php echo e($item->id); ?>" class="modal fade">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content tx-size-sm">
                        <div class="modal-header pd-x-20">
                            <h6 class="tx-14 mg-b-0 tx-uppercase tx-inverse tx-bold"> Modify trade <?php echo e($item->id); ?> => <?php echo e(amt($item->traded_amount)); ?></h6>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form action="<?php echo e(route('admin.user.updateTrade')); ?>" method="POST">

                            <div class="modal-body pd-20">

                                <?php echo csrf_field(); ?>
                                <div class="form-layout form-layout-1">
                                    <div class="row mg-b-25">

                                        <input name="id" type="hidden" value="<?php echo e($item->id); ?>">

                                        <div class="col-md-12">
                                            <div class="form-group mg-b-10-force">
                                                <label class="form-control-label"> Outcome: <span class="tx-danger">*</span></label>
                                                <select name="outcome" class="form-control" required>
                                                    <option value="1">Won</option>
                                                    <option value="0">Lost</option>
                                                </select>
                                            </div>
                                        </div><!-- col-8 -->
                                        <div class="col-md-12">
                                            <div class="form-group mg-b-10-force">
                                                <label class="form-control-label"> PNL: <span class="tx-danger">*</span></label>
                                                <input value="<?php echo e($item->profit); ?>" class="form-control" required type="number" step="any" name="profit" placeholder="PNL">
                                            </div>
                                        </div><!-- col-8 -->
                                    </div>
                                </div>

                            </div><!-- modal-body -->
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary tx-size-xs">Save</button>
                                <button type="button" class="btn btn-secondary tx-size-xs" data-dismiss="modal">Close</button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div><!-- br-mainpanel -->
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('admin.partials.dt-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        var transactionsToDelete = [];
        function toggleTransactionToDelete(obj) {
            if (obj.checked) transactionsToDelete.push(obj.value)
            else transactionsToDelete.splice(transactionsToDelete.indexOf(obj.value), 1);

            var transactionCount = transactionsToDelete.length;
            if (transactionCount > 0) {
                // show delete multiple button
                $('.delete-multiple-transactions').show().html(`Delete ${transactionsToDelete.length} ${transactionCount > 1 ? 'Transactions' : 'Transaction'}`);
                $('.delete-transaction-btn').hide();
            } else {
                $('.delete-multiple-transactions').hide();
                $('.delete-transaction-btn').show();

            }
        }

        $('.delete-multiple-transactions').click(function (e) {
            e.preventDefault();
            deleteTransactions()
        });

        function deleteTransactions (id = null) {
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    console.log(id)
                    if (id == null) {
                        $('#deleteTransactionForm').submit();
                        console.log('delete multiple')
                    } else {
                        // delete single transaction
                        // var transactionId = 2
                        $('#deleteTransactionForm').attr('action', `/admin/users/transactions/${id}/delete`).submit();
                        console.log('single multiple')
                    }
                }
            })
        }
    </script>









    <script>
        var tradesToDelete = [];
        function toggleTradeToDelete(obj) {
            if (obj.checked) tradesToDelete.push(obj.value)
            else tradesToDelete.splice(tradesToDelete.indexOf(obj.value), 1);

            var tradeCount = tradesToDelete.length;
            if (tradeCount > 0) {
                // show delete multiple button
                $('.delete-multiple-trades').show().html(`Delete ${tradesToDelete.length} ${tradeCount > 1 ? 'Trades' : 'Trade'}`);
                $('.delete-trade-btn').hide();
            } else {
                $('.delete-multiple-trades').hide();
                $('.delete-trade-btn').show();

            }
        }

        $('.delete-multiple-trades').click(function (e) {
            e.preventDefault();
            deleteTrades()
        });

        function deleteTrades (id = null) {
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    console.log(id)
                    if (id == null) {
                        $('#deleteTradeForm').submit();
                        console.log('delete multiple')
                    } else {
                        // delete single trade
                        // var tradeId = 2
                        $('#deleteTradeForm').attr('action', `/admin/users/trades/${id}/delete`).submit();
                        console.log('single multiple')
                    }
                }
            })
        }
    </script>


    <script>
        
        
        let coin = '<?php echo json_encode(App\Models\CurrencyPair::first()->id, 15, 512) ?>'
        let userId = "<?php echo e($user->id); ?>"

        let c_type = "<?php echo e($c_type); ?>"

        let updateTrade = "<?php echo e(route('admin.user.updateTrade')); ?>"

        let currentUrl = "<?php echo e(request()->url()); ?>?user=<?php echo e($user->id); ?>"

        let int = "<?php echo e(setting('api_interval',1000)); ?>"

        
        
        document.addEventListener('DOMContentLoaded', function () {
            new Vue({
                el: '#photos',
                data() {
                    return {
                        name : 'crypo',
                        asset : '',
                        eId : null,
                        calculating : false,
                        eOP:null,
                        interval : 10000,
                        form : null,
                        all_trades : [],
                        data : {
                            coin_id : '',
                            a_type : c_type,
                            value : 0,
                            volume : 0,
                            amount : 0,
                            type : 'buy',
                            leverage : 0,
                            is_stop_loss:0,
                            is_take_profit:0,
                            stop_loss:100,
                            take_profit:100,
                            user_id : userId,
                        },
                        coinPrice : 0,
                        currency : null
                    }
                },
                mounted() {
                    this.data.coin_id = coin;
                    this.interval = parseInt(int) + 1000;
                    this.getCoin(coin);
                    this.getAllTrades();
                },
                methods : {
                    updateStatus(item){
                        this.getCoin(item)
                    },
                    editTrade(item){
                        this.edit = true;
                        this.calculating = false;
                        this.eId = item.id;
                        this.eOP = item.opening_price;
                        this.form = item
                        let element = this.$refs.modal
                        $(element).modal('show');
                    },
                    startUpdate(){
                        console.log('updating interval .... ='+this.interval)
                        this.updateProfits();
                        this.timer = setInterval(() => {
                            this.updateProfits();
                        }, this.interval)
                    },

                    updateProfits(){
                        axios.get('/admin/update/profit/'+userId).then((res) => {
                            this.all_trades = res.data;
                        })
                    },
                    updateTrade(){
                        this.calculating = true
                        axios.post(updateTrade, { id : this.eId, opening_price : this.eOP, api : true}).then((res) => {
                            this.form.profit = res.data.profit;
                            this.calculating = false
                        }).catch(()=>{
                            this.calculating = false
                        })
                    },
                    getCurPrice(){
                        axios.get('/api/cur/rate/'+this.currency.sym+'/'+this.currency.base+'/'+this.currency.type).then((res) =>{
                            this.coinPrice = res.data;
                            this.data.value = this.coinPrice;
                        })
                    },

                    getAllTrades(){
                        axios.get('/admin/get/all_trades/'+userId).then((res) =>{
                            this.all_trades = res.data;
                            if(this.all_trades.length > 0){
                                this.startUpdate();
                            }
                        })
                    },
                    getCoin(coin){
                        axios.get('/admin/get/coin/'+coin).then((res) =>{
                            this.coinPrice = res.data.rate;
                            this.data.value = res.data.rate;
                            this.currency = res.data;
                        })
                    },

                },

                computed : {
                    assets(){

                    },
                    aType(){
                        return this.data.a_type;
                    },
                    vVolume(){
                        return this.data.volume;
                    },
                    openingRate(){
                        if(this.form){
                            return this.form.opening_price;
                        }
                    },
                    amount(){
                        return this.data.amount;
                    }
                },

                watch: {
                    eOP(){
                        this.updateTrade();
                    },
                    vVolume(){
                        this.data.amount = (this.data.volume * this.coinPrice) / this.currency.leverage;
                    },
                    // amount(){
                    //     this.data.volume = this.data.amount / this.coinPrice;
                    // },
                    aType(){
                        let new_url = currentUrl+'&asset='+this.data.a_type
                        window.location = new_url;
                    },
                    openingRate(){
                        console.log(this.form)
                    },
                    currency() {
                        this.data.leverage = this.currency.leverage;
                        this.getCurPrice();
                    },
                }
            })
        })
    </script>

<script>
    $(document).ready(function() {
        $('.but_delete_action').click(function( event ) {
            if (confirm('Are you sure you want to delete the item?')) {
                var deleteId = $(this).data('delete');
                document.getElementById(deleteId).submit();
            }
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u518791033/domains/web-terminal.online/public_html/resources/views/admin/users/show.blade.php ENDPATH**/ ?>