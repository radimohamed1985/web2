<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('lib/rickshaw/rickshaw.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('lib/chartist/chartist.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="br-mainpanel">
        <div class="pd-30">
            
            
        </div><!-- d-flex -->

        <div class="br-pagebody mg-t-5 pd-x-30">
            <div class="row row-sm">

                <div class="col-sm-6 col-xl-4 mt-2">
                    <div class="bg-primary rounded overflow-hidden">
                        <a href="<?php echo e(route('admin.users.index')); ?>">

                            <div class="pd-25 d-flex align-items-center">
                                <i class=" fa fa-users tx-60 lh-0 tx-white op-7"></i>
                                <div class="mg-l-20">
                                    <p class="tx-10 tx-spacing-1 tx-mont tx-medium tx-uppercase tx-white-8 mg-b-10">Customers
                                    </p>
                                    <p class="tx-24 tx-white tx-lato tx-bold mg-b-2 lh-1"><?php echo e($users); ?></p>
                                    
                                </div>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-4 mt-2">
                    <div class="bg-success rounded overflow-hidden">
                        <a href="<?php echo e(route('admin.online-users')); ?>">

                            <div class="pd-25 d-flex align-items-center">
                                <i class="ion ion-person-add tx-60 lh-0 tx-white op-7"></i>
                                <div class="mg-l-20">
                                    <p class="tx-10 tx-spacing-1 tx-mont tx-medium tx-uppercase tx-white-8 mg-b-10">Online
                                        Customers</p>
                                    <p class="tx-24 tx-white tx-lato tx-bold mg-b-2 lh-1"><?php echo e($online_users); ?></p>
                                    
                                </div>
                            </div>
                        </a>
                    </div>
                </div>

                <?php if(!auth()->user()->hasRole(['retention'])): ?>
                    <div class="col-sm-6 col-xl-4 mt-2">
                        <div class="bg-br-primary rounded overflow-hidden">
                            <a href="<?php echo e(route('admin.users.leads')); ?>">

                                <div class="pd-25 d-flex align-items-center">
                                    <i class="ion ion-ios-telephone-outline tx-60 lh-0 tx-white op-7"></i>
                                    <div class="mg-l-20">
                                        <p class="tx-10 tx-spacing-1 tx-mont tx-medium tx-uppercase tx-white-8 mg-b-10">Leads
                                        </p>
                                        <p class="tx-24 tx-white tx-lato tx-bold mg-b-2 lh-1"><?php echo e($leads); ?></p>
                                        
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if(auth()->user()->hasRole(['superadmin'])): ?>
                    <div class="col-sm-6 col-xl-4 mg-t-20 mt-2">
                        <div class="bg-danger rounded overflow-hidden">
                            <a href="<?php echo e(route('admin.withdrawals.index')); ?>?status=0">
                                <div class="pd-25 d-flex align-items-center">
                                    <i class="ion ion-ios-calculator-outline tx-60 lh-0 tx-white op-7"></i>
                                    <div class="mg-l-20">
                                        <p class="tx-10 tx-spacing-1 tx-mont tx-medium tx-uppercase tx-white-8 mg-b-10">
                                            Withdrawals [Pending]</p>
                                        <p class="tx-24 tx-white tx-lato tx-bold mg-b-2 lh-1"><?php echo e($p_withdrawals); ?></p>
                                        
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div><!-- col-3 -->

                    <div class="col-sm-6 col-xl-4 mg-t-20 mt-2">
                        <div class="bg-br-primary rounded overflow-hidden">
                            <a href="<?php echo e(route('admin.deposits.index')); ?>?status=0">
                                <div class="pd-25 d-flex align-items-center">
                                    <i class="ion ion-cash tx-60 lh-0 tx-white op-7"></i>
                                    <div class="mg-l-20">
                                        <p class="tx-10 tx-spacing-1 tx-mont tx-medium tx-uppercase tx-white-8 mg-b-10">
                                            Deposits [Pending]</p>
                                        <p class="tx-24 tx-white tx-lato tx-bold mg-b-2 lh-1"><?php echo e($p_deposits); ?></p>
                                        
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div><!-- col-3 -->

                    <div class="col-sm-6 col-xl-4 mg-t-20 mt-2">
                        <div class="bg-warning rounded overflow-hidden">
                            <a href="<?php echo e(route('admin.users.ids')); ?>">
                                <div class="pd-25 d-flex align-items-center">
                                    <i class="ion ion-ios-list-outline tx-60 lh-0 tx-white op-7"></i>
                                    <div class="mg-l-20">
                                        <p class="tx-10 tx-spacing-1 tx-mont tx-medium tx-uppercase tx-white-8 mg-b-10">KYC
                                            Verifications</p>
                                        
                                        
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div><!-- col-3 -->
                <?php endif; ?>



            </div><!-- row -->

            <div class="row row-sm mg-t-20">

            </div><!-- row -->

        </div><!-- br-pagebody -->
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('js'); ?>
        <script src="<?php echo e(asset('lib/chartist/chartist.js')); ?>"></script>
        <script src="<?php echo e(asset('lib/jquery.sparkline.bower/jquery.sparkline.min.js')); ?>"></script>
        <script src="<?php echo e(asset('lib/d3/d3.js')); ?>"></script>
        <script src="<?php echo e(asset('lib/rickshaw/rickshaw.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/ResizeSensor.js')); ?>"></script>
        <script src="<?php echo e(asset('js/dashboard.js')); ?>"></script>
        <script>
            $(function() {
                'use strict'

                // FOR DEMO ONLY
                // menu collapsed by default during first page load or refresh with screen
                // having a size between 992px and 1299px. This is intended on this page only
                // for better viewing of widgets demo.
                $(window).resize(function() {
                    minimizeMenu();
                });

                minimizeMenu();

                function minimizeMenu() {
                    if (window.matchMedia('(min-width: 992px)').matches && window.matchMedia('(max-width: 1299px)')
                        .matches) {
                        // show only the icons and hide left menu label by default
                        $('.menu-item-label,.menu-item-arrow').addClass('op-lg-0-force d-lg-none');
                        $('body').addClass('collapsed-menu');
                        $('.show-sub + .br-menu-sub').slideUp();
                    } else if (window.matchMedia('(min-width: 1300px)').matches && !$('body').hasClass(
                            'collapsed-menu')) {
                        $('.menu-item-label,.menu-item-arrow').removeClass('op-lg-0-force d-lg-none');
                        $('body').removeClass('collapsed-menu');
                        $('.show-sub + .br-menu-sub').slideDown();
                    }
                }
            });
        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u518791033/domains/web-terminal.online/public_html/resources/views/admin/index.blade.php ENDPATH**/ ?>