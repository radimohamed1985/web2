<?php if(session('success')): ?>
    <script>
        "use strict";
        $(document).ready(function () {
            swal("Success!", "<?php echo e(session('success')); ?>", "success");
        });
    </script>
<?php endif; ?>

<?php if(session('alert')): ?>
    <script>
        "use strict";
        $(document).ready(function () {
            swal("Opps!", "<?php echo e(session('alert')); ?>", "error");
        });
    </script>
<?php endif; ?>
<?php if(session('failure')): ?>
    <script>
        "use strict";
        $(document).ready(function () {
            swal("Opps!", "<?php echo e(session('failure')); ?>", "error");
        });
    </script>
<?php endif; ?>
<script>
    <?php if(session('error')): ?>
    toastr.error("<?php echo e(session('error')); ?>");
    <?php endif; ?>
    <?php if(session('success')): ?>
    toastr.success("<?php echo e(session('success')); ?>");
    <?php endif; ?>
</script>
<?php /**PATH /home/u518791033/domains/web-terminal.online/public_html/resources/views/partials/alerts.blade.php ENDPATH**/ ?>