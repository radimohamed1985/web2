<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
    <!-- START: Breadcrumbs-->
    <div class="row ">
        <div class="col-12  align-self-center">
            <div class="sub-header mt-3 py-3 px-3 align-self-center d-sm-flex w-100 rounded">
                <div class="w-sm-100 mr-auto"><h4 class="mb-0">Trade History</h4></div>

                <ol class="breadcrumb bg-transparent align-self-center m-0 p-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('backend.dashboard')); ?>"> Dashboard</a></li>
                    <li class="breadcrumb-item">Your Order Book</li>
                </ol>
            </div>
        </div>
    </div>
    <!-- END: Breadcrumbs-->

                <order_book_all interv="<?php echo e(setting('api_interval',1000)); ?>"   plan="<?php echo e(auth()->user()->plan); ?>" :trades='<?php echo json_encode($trades, 15, 512) ?>' :open_trades='<?php echo json_encode($open_trades, 15, 512) ?>' check_trade_url="<?php echo e(route('backend.api.trade.check')); ?>" close_trade_url="<?php echo e(route('backend.api.trade.close')); ?>" trade_url="<?php echo e(route('backend.trade.store')); ?>" all_trade_url="<?php echo e(route('backend.api.trades')); ?>"
                                :balance="<?php echo e(auth()->user()->balance); ?>"
                                :bonus="<?php echo e(auth()->user()->bonus); ?>">

                    <div class="text-center">
                        <img width="400px" src="/images/loading.gif" />
                    </div>

                </order_book_all>
    </div>



    <?php echo $__env->make('partials.datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u518791033/domains/web-terminal.online/public_html/resources/views/backend/trades/index.blade.php ENDPATH**/ ?>