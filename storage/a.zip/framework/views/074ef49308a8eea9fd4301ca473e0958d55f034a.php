
<link href="<?php echo e(asset('lib/highlightjs/github.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('lib/datatables/jquery.dataTables.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('lib/select2/css/select2.min.css')); ?>" rel="stylesheet">
<?php /**PATH /home/u518791033/domains/web-terminal.online/public_html/resources/views/admin/partials/dt-css.blade.php ENDPATH**/ ?>