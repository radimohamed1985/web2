<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!-- START: Breadcrumbs-->
        <div class="row ">
            <div class="col-12  align-self-center">
                <div class="sub-header mt-3 py-3 px-3 align-self-center d-sm-flex w-100 rounded">
                    <div class="w-sm-100 mr-auto"><span class="h4 my-auto text-capitalize"><?php echo e(auth()->user()->name); ?></span></div>

                    <ol class="breadcrumb bg-transparent align-self-center m-0 p-0">
                        <li class="breadcrumb-item">Dashboard</li>
                        <li class="breadcrumb-item active" aria-current="page"><a href="#">Profile</a></li>
                    </ol>
                </div>
            </div>
        </div>
        <!-- END: Breadcrumbs-->

        <div class="container py-5">
            <?php if(Auth::user()->referred_by > 0): ?>
                <p>Referred by: <strong>
                    <?php echo e(DB::table('users')->where('id', Auth::user()->referred_by)->value('username')); ?>

                </strong></p>
            <?php endif; ?>
            <!-- <?php if(Auth::user()->referred_by != NULL): ?>
                <p>Referred by: <strong>
                    <?php echo e(DB::table('users')->where('id', Auth::user()->referred_by)->value('username')); ?>

                </strong></p>
            <?php endif; ?> -->
            <p>
                <!--Referrer's link: <a href="<?php echo e(url('/ref/' . Auth::user()->id)); ?>" target="__blank"><?php echo e(url('/ref/' . Auth::user()->id)); ?></a>-->
            </p>
            <p>
               <!-- You have referred: <strong><?php echo e($ref = DB::table('users')->where('referred_by', Auth::user()->id)->count()); ?></strong> <?php echo e($ref < 1 ? 'people' : 'peoples'); ?>.-->
            </p>
            <?php if(auth()->user()->hasRole(['superadmin','admin','manager'])): ?>
                <p>
                    <form action="<?php echo e(route('backend.user.token.generate')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php if(auth()->user()->access_token): ?>
                            <div class="input-group my-3">
                                <?php
                                    $token = auth()->user()->access_token; 
                                ?>
                            <!--    <input type="text" id="walletAddress" readonly value="<?php echo e($token); ?>" class="form-control" placeholder="Wallet Address" aria-describedby="basic-addon2">
                                <div class="input-group-append">
                                    <button class="btn btn-outline-secondary" onclick="copyAccessToken('<?php echo e($token); ?>')" type="button">
                                        <span class="fa fa-copy" id="copyText"></span>
                                    </button>-->
                                </div>
                            </div>
                        <?php endif; ?>
                       <!-- <button class="btn btn-primary">Generate Access Token</button>-->
                    </form>
                </p>
            <?php endif; ?>

        <!-- START: Card Data-->

        <profile :user='<?php echo json_encode(auth()->user(), 15, 512) ?>' :accounts='<?php echo json_encode($accounts, 15, 512) ?>' :messages='<?php echo json_encode($messages, 15, 512) ?>'
                 :transactions='<?php echo json_encode($transactions, 15, 512) ?>'
                 interv="<?php echo e(setting('api_interval',1000)); ?>"
                 plan="<?php echo e(auth()->user()->plan); ?>"
                 :trades='<?php echo json_encode($trades, 15, 512) ?>'
                 :open_trades='<?php echo json_encode($open_trades, 15, 512) ?>'
                 check_trade_url="<?php echo e(route('backend.api.trade.check')); ?>"
                 close_trade_url="<?php echo e(route('backend.api.trade.close')); ?>"
                 trade_url="<?php echo e(route('backend.trade.store')); ?>"
                 all_trade_url="<?php echo e(route('backend.api.trades')); ?>"
        >

        </profile>

        <!-- END: Card DATA-->
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript">
        function copyAccessToken(accessToken) {
            console.log(accessToken);
            navigator.clipboard.writeText(accessToken);
            document.getElementById('copyText').innerHTML = ' Copied!'
            setTimeout(() => {
                document.getElementById('copyText').innerHTML = '';
            }, 2000);
        }
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u518791033/domains/web-terminal.online/public_html/resources/views/backend/overview.blade.php ENDPATH**/ ?>