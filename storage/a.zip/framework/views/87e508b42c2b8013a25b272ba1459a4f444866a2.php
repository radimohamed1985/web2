<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Twitter -->
    <meta name="twitter:site" content="@themepixels">
    <meta name="twitter:creator" content="@themepixels">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo e(setting('site_name')); ?>">
    <meta name="twitter:description" content="<?php echo e(setting('site_description')); ?>">
    <meta name="twitter:image" content="<?php echo e(asset('bracket/img/bracket-social.png')); ?>">

    <!-- Facebook -->
    <meta property="og:url" content="<?php echo e(setting('site_url')); ?>">
    <meta property="og:title" content="<?php echo e(setting('site_name')); ?>">
    <meta property="og:description" content="<?php echo e(setting('site_description')); ?>">

    <link rel="stylesheet" href="/dist/vendors/toastr/toastr.min.css"/>








    <!-- Meta -->
    <meta name="description" content="<?php echo e(setting('site_description')); ?>">
    <meta name="author" content="<?php echo e(setting('site_name')); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(setting('site_title')); ?></title>

    <link href="<?php echo e(asset('font-awesome/css/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('lib/Ionicons/css/ionicons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('lib/perfect-scrollbar/css/perfect-scrollbar.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('lib/jquery-switchbutton/jquery.switchButton.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/dist/css/bootstrap-select.css')); ?>">


    <link href="<?php echo e(asset('lib/select2/css/select2.min.css')); ?>" rel="stylesheet">

    <!-- FAVICONS ICON -->

    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(setting('favicon','/images/fav.png')); ?>">

    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(setting('favicon','/images/fav.png')); ?>" />

    <?php echo $__env->yieldContent('style'); ?>
    <!-- Bracket CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bracket.css')); ?>">

    <style>
        [v-cloak] { display: none; }

        .alert-danger {
            color: #ffff!important;
            background-color: #F44336!important;
            border-color: #F44336!important;
        }

        .br-section-wrapper {
            padding: 15px!important;
        }
        /*.br-menu-item {*/
        /*    height: 30px;*/
        /*    letter-spacing: 0.1px;*/
        /*    !*font-size: .65rem;*!*/
        /*}*/
        /*.br-menu-item .svg-inline--fa{*/
        /*    width: 1.05em!important;*/
        /*}*/
    </style>

    <?php echo $__env->yieldContent('headJS'); ?>;
</head>

<body>

<?php echo $__env->make('admin.layouts.admin-sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- ########## START: MAIN PANEL ########## -->


    <?php echo $__env->yieldContent('content'); ?>

    <footer class="br-footer py-2" style="position: fixed; bottom: 0; width: 100%;">
        <div class="footer-left">
            <div class="mg-b-2">Copyright &copy; <?php echo e(date('Y')); ?>. <?php echo e(setting('site_name')); ?>. All Rights Reserved.</div>
        </div>
    </footer>

<!-- ########## END: MAIN PANEL ########## -->


    <script src="<?php echo e(asset('lib/jquery/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/popper.js/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/bootstrap/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/perfect-scrollbar/js/perfect-scrollbar.jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/moment/moment.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/jquery-ui/jquery-ui.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/jquery-switchbutton/jquery.switchButton.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/peity/jquery.peity.js')); ?>"></script>
    
    <script src="<?php echo e(asset('js/bracket.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dist/js/bootstrap-select.js')); ?>"></script>
<script src="/dist/vendors/toastr/toastr.min.js"></script>

<script src="/vendor/laravel-filemanager/js/stand-alone-button.js"></script>





<script src="https://cdn.jsdelivr.net/npm/vue@2.6.14"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.19.0/axios.min.js"></script>


<script>
    $('.lfm').filemanager('image');
</script>

<script>
    $(document).ready(function() {
        $("#showActions").click(function() {
            $("#actions-details").toggle();
        });
        $('.selectpicker').selectpicker();
    })
</script>

    <?php echo $__env->yieldContent('js'); ?>

<?php echo $__env->make('partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH /home/u518791033/domains/web-terminal.online/public_html/resources/views/admin/layouts/admin-app.blade.php ENDPATH**/ ?>