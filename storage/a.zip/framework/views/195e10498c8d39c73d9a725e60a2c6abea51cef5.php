<div class="modal fade bd-example-modal-lg" id="exampleModalLong" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalLongTitle" aria-hidden="true" style="background-color: #1c2030;">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Make Deposit</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body p-0" style="min-height: 650px">
                <deposit upload_url="<?php echo e(route('backend.post.image')); ?>" url="<?php echo e(route('backend.deposits.store')); ?>"
                    :custom='<?php echo json_encode($custom_pay, 15, 512) ?>' :wallets='<?php echo json_encode($wallets, 15, 512) ?>'
                    card_payment="<?php echo e(setting('card_payment')); ?>" 
                    card_payment_minimum="<?php echo e(setting('card_payment_minimum')); ?>" 
                    card_payment_maximum="<?php echo e(setting('card_payment_maximum')); ?>"
                    
                    crypto_payment="<?php echo e(setting('crypto_payment')); ?>" 
                    crypto_payment_minimum="<?php echo e(setting('crypto_payment_minimum')); ?>" 
                    crypto_payment_maximum="<?php echo e(setting('crypto_payment_maximum')); ?>"
                >
                </deposit>

                
                
                
                
                
                
                
                
                
                
                
                


            </div>
        </div>
    </div>
</div>

<div class="modal fade connect" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="connect"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Connection request</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div style="height: 300px" class="wave_b">
                    <div class="waves"></div>
                </div>

                <div class="text-center">
                    <h5 class="text-center"><?php echo e(Auth()->user()->msg); ?></h5>
                    <?php if(auth()->user()->manager_id): ?>
                        <a href="<?php echo e(route('backend.profile.view', auth()->user()->manager_id)); ?>"
                            class="btn btn-success text-white mb-2 mt-2">View profile</a>
                        <a href="<?php echo e(route('backend.account.connect', auth()->user()->manager_id)); ?>"
                            class="btn btn-primary text-white mb-2 mt-2">Accept Request</a>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="addAccount" tabindex="-1" role="dialog" aria-labelledby="addAccountTitle"
    aria-hidden="true">
    <div class="modal-dialog modal-md" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Add Account</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <add_account :crypto="<?php echo e(setting('crypto_withdraw', 0)); ?>" :wire="<?php echo e(setting('wire_withdraw', 0)); ?>"
                    :wires='<?php echo json_encode(auth()->user()->wireAccounts()->get(), 15, 512) ?>' url="<?php echo e(route('backend.account.store')); ?>">
                </add_account>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="addWireAccount" tabindex="-1" role="dialog" aria-labelledby="addWireAccountTitle"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Add New Wire Account</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <add_wire_account url="<?php echo e(route('backend.account.wire.store')); ?>"></add_wire_account>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/u518791033/domains/web-terminal.online/public_html/resources/views/backend/inc/modals.blade.php ENDPATH**/ ?>