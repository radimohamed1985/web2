<div class="input-group">
   <span class="input-group-btn">
     <a  data-input="<?php echo e($id); ?>" data-preview="<?php echo e($id); ?>_holder" class="btn btn-primary lfm">
       <i class="fas fa-picture"></i> Choose Image
     </a>
   </span>
    <?php if(isset($image)): ?>
        <input id="<?php echo e($id); ?>" class="form-control" type="hidden" value="<?php echo e($image); ?>" name="<?php echo e($field); ?>">
        <input disabled class="form-control" value="<?php echo e($image); ?>" type="text">
    <?php else: ?>
        <input id="<?php echo e($id); ?>" class="form-control" type="hidden" name="<?php echo e($field); ?>">
        <input disabled class="form-control" value="" type="text">
    <?php endif; ?>
</div>
<div id="<?php echo e($id); ?>_holder" style="margin-top:15px; margin-bottom:20px;max-height:200px;"></div>

<?php /**PATH /home/u518791033/domains/web-terminal.online/public_html/resources/views/admin/partials/image-upload.blade.php ENDPATH**/ ?>