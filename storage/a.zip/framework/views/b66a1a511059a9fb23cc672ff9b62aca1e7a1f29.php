<tr>
	<td class="w40" width="40"></td>
	<td class="w560" width="560">
		<table class="w560" border="0" cellpadding="0" cellspacing="0" width="560">
			<tbody>
			<tr><td class="w560" height="15" width="560"></td></tr>
			<tr><td class="w560" height="15" width="560"></td></tr>
			<tr>
				<td class="w560" width="560">
					<div class="article-content" align="left"><?php /**PATH /home/u518791033/domains/web-terminal.online/public_html/vendor/snowfire/beautymail/src/Snowfire/Beautymail/../../views/templates/sunny/contentStart.blade.php ENDPATH**/ ?>