<div class="sidebar">
    <a href="#"
        class="sidebarCollapse float-right h6 dropdown-menu-right mr-2 mt-2 position-absolute d-block d-sm-none d-md-none d-lg-none">
        <i class="icon-close"></i>
    </a>
    <!-- START: Logo-->
    <!-- <a href="<?php echo e(env('SITE_URL')); ?>" class="sidebar-logo d-flex d-sm-none d-md-none d-lg-none">
        <img src="<?php echo e(setting('favicon', 'asset/images/logosm.png')); ?>" alt="logo" width="100" class="img-fluid mr-2"/> -->
    <a href="<?php echo e(setting('site_info_url', '/')); ?>" class="sidebar-logo d-flex d-sm-none d-md-none d-lg-none">
        <img src="<?php echo e(setting('logo', '/asset/images/logosm.png')); ?>" alt="logo" width="100" class="img-fluid mr-2" />
        
    </a>
    <!-- END: Logo-->

    <!-- START: Menu-->
    <ul id="side-menu" class="sidebar-menu">

        <?php if(auth()->user()->hasRole('dev')): ?>
            <li class="<?php echo e(active('backend.dashboard')); ?>"><a href="<?php echo e(route('backend.dashboard')); ?>"><i
                        class="icon-speedometer"></i>Dashboard</a></li>

            <?php if(setting('trade')): ?>
            <li class="<?php echo e(active('backend.tradestation')); ?>"><a href="<?php echo e(route('backend.tradestation')); ?>"><i
                        class="icon-chart"></i>Trade Station</a></li>
            <?php endif; ?>
        <?php else: ?>
            <?php if(setting('trade')): ?>
            <li class="<?php echo e(active('backend.tradestation')); ?>"><a href="<?php echo e(route('backend.tradestation')); ?>"><i
                        class="icon-speedometer"></i>Trade Station</a></li>
        <?php endif; ?>
        <?php endif; ?>

        <?php if(setting('trade')): ?>
            <li class="<?php echo e(active('backend.trades.index')); ?>">
                <?php
                $count = \App\Models\Trade::whereUserId(auth()->id())->whereStatus(0)->count();
                ?>


                <a href="<?php echo e(route('backend.trades.index')); ?>">
                    <update_user :trades="<?php echo e($count); ?>"></update_user>

                    <i class="fa fa-film">
                    </i>

                    Order Book

                </a></li>


            
            <li class="<?php echo e(active('backend.markets')); ?>"><a href="<?php echo e(route('backend.markets')); ?>"><i
                        class="icon-film"></i>Market</a></li>

                <li class="<?php echo e(active('backend.trade.plans')); ?>"><a href="<?php echo e(route('backend.trade.plans')); ?>"><i
                            class="fa fa-cubes"></i>Trading Plans</a></li>
        <?php endif; ?>
        


        <?php if(setting('exchange')): ?>
                <li class="<?php echo e(active('backend.plans')); ?>"><a href="<?php echo e(route('backend.plans')); ?>"><i
                            class="fa fa-cubes"></i>Crypto Exchange</a></li>
            <?php endif; ?>

        <?php if(setting('invest')): ?>
                <li class="<?php echo e(active('backend.investments')); ?>"><a href="<?php echo e(route('backend.investments')); ?>"><i
                            class="icon-chart"></i>Investments</a></li>

                <li class="<?php echo e(active('backend.plans')); ?>"><a href="<?php echo e(route('backend.plans')); ?>"><i
                            class="fa fa-cubes"></i>Investment Plans</a></li>


        <?php endif; ?>

            <li class="<?php echo e(active('backend.transactions')); ?>"><a href="<?php echo e(route('backend.transactions')); ?>"><i
                        class="icon-list"></i>Transaction History</a></li>


            




        <!-- <li class="dropdown"><a href="#"><i class="icon-user"></i>Overview</a>
            <div>
                <ul>
                    <li><a href="<?php echo e(route('backend.account.overview')); ?>"><i class="icon-people"></i> Profile Overview </a></li>
                    <li><a href="<?php echo e(route('backend.profile.edit')); ?>"><i class="fas fa-edit"></i> Edit Profile </a></li>
                    <li><a href="<?php echo e(route('backend.account.security')); ?>"><i class="icon-cursor-move"></i> Security Setting</a></li>
                    <li><a href="<?php echo e(route('backend.account.overview')); ?>"><i class="icon-user"></i> Account Plan</a></li>

                </ul>
            </div>
        </li> -->

        <?php if(setting('autotrader')): ?>
            <li class=""><a href="<?php echo e(route('backend.autotraders')); ?>">
                    <i class="icon-user"></i>Auto Traders</a></li>
        <?php endif; ?>


                <li class=""><a href="<?php echo e(route('backend.account.overview')); ?>">
                        <i class="icon-user"></i>Profile</a></li>


            <?php if(setting('multi_lang')): ?>
                <li class=""><a href="#">
                        <i class="icon-flag"></i>English</a></li>
            <?php endif; ?>

            <?php if(setting('referrals')): ?>
                <li class="<?php echo e(active('backend.refer')); ?>"><a href="<?php echo e(route('backend.refer')); ?>">
                        <i class="icon-share-alt"></i>Referrals</a></li>
            <?php endif; ?>

    </ul>
    <!-- END: Menu-->
</div>
<?php /**PATH /home/u518791033/domains/web-terminal.online/public_html/resources/views/partials/backend/sidebar.blade.php ENDPATH**/ ?>