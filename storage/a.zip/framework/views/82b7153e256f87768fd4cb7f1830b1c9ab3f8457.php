<?php $__env->startSection('style'); ?>
    <?php echo $__env->make('admin.partials.dt-css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="br-mainpanel">
        <div class="br-pageheader pd-y-15 pd-l-20">
            <nav class="breadcrumb pd-0 mg-0 tx-12">
                <a class="breadcrumb-item" href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
                <a class="breadcrumb-item" href="#">Identities</a>
            </nav>
        </div><!-- br-pageheader -->

        <div class="pd-x-20 pd-sm-x-30 pd-t-20 pd-sm-t-30">
            <h4 class="tx-gray-800 mg-b-5"> Uploaded Identity</h4>
        </div>



        <div class="br-pagebody">

            <div class="br-section-wrapper">

                <?php echo $__env->make('notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="table-wrapper">
                    <table id="datatable1" class="table display table-bordered responsive nowrap">
                        <thead>
                        <tr>
                            <th class="wd-10p">S/N</th>
                            <th  class="wd-15p">User</th>
                            <th class="wd-15p">Front ID</th>
                            <th class="wd-15p">Back ID</th>
                            <th class="wd-15p">Credit Card Front</th>
                            <th class="wd-15p">Credit Card Back</th>
                            <th class="wd-15p">Proof Of Address</th>
                            <th class="wd-15p">Status&nbsp; </th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php
                            $count = 1;
                        ?>
                        <?php $__currentLoopData = $ids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->user): ?>
                                <tr>
                                    <td><?php echo e($count++); ?></td>
                                    <td><a href="<?php echo e(route('admin.users.show',$item->user->id)); ?>"><?php echo e($item->user->name); ?></a> </td>
                                    <td>
                                        <?php if($item->front): ?>
                                            <a href="<?php echo e($item->front); ?>" target="_blank">
                                                <img height="50px" width="50px" src="<?php echo e($item->front); ?>" />
                                            </a>
                                            <br>
                                            <small><?php echo e($item->type); ?></small>
                                        <?php else: ?>
                                            Not uploaded
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($item->back): ?>
                                            <a href="<?php echo e($item->back); ?>" target="_blank">
                                                <img height="50px" width="50px" src="<?php echo e($item->back); ?>" />
                                            </a>
                                            <br>
                                            <small><?php echo e($item->type); ?></small>
                                        <?php else: ?>
                                            Not Uploaded
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($item->credit_card_front): ?>
                                            <a href="<?php echo e($item->credit_card_front); ?>" target="_blank">
                                                <img height="50px" width="50px" src="<?php echo e($item->credit_card_front); ?>" />
                                            </a>
                                        <?php else: ?>
                                            Not uploaded
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($item->credit_card_back): ?>
                                            <a href="<?php echo e($item->credit_card_back); ?>" target="_blank">
                                                <img height="50px" width="50px" src="<?php echo e($item->credit_card_back); ?>" />
                                            </a>
                                        <?php else: ?>
                                            Not uploaded
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($item->proof_of_address): ?>
                                            <a href="<?php echo e($item->proof_of_address); ?>" target="_blank">
                                                <img height="50px" width="50px" src="<?php echo e($item->proof_of_address); ?>" />
                                            </a>
                                            <br>
                                            <small><?php echo e($item->proof_of_address_type); ?></small>
                                        <?php else: ?>
                                            Not uploaded
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="mb-2 badge badge-pill <?php if($item->status == 'approved'): ?> badge-success <?php elseif($item->status == 'disapproved'): ?> badge-danger <?php else: ?> badge-secondary <?php endif; ?>"><?php echo e($item->status); ?></span>
                                        <br />
                                        <?php if($item->status != 'approved'): ?>
                                            <a href="#" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#approval<?php echo e($item->id); ?>">Approve</a>
                                            

                                            <div class="modal fade" id="approval<?php echo e($item->id); ?>" tabindex="0" aria-labelledby="Notes" aria-hidden="true" data-backdrop="static" data-keyboard="false" >
                                                <div class="modal-dialog modal-lg">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title">Approving <?php echo e($item->user->name); ?><h5>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <form action="<?php echo e(route('admin.approve.id', $item->id)); ?>" method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="modal-body">
                                                                <div class="row">
                                                                    <label class="col-sm-12 form-control-label">Approval Message:</label>
                                                                    <div class="col-sm-12">
                                                                        <textarea class="form-control" style="width: 100%" placeholder="Message" name="message" required></textarea>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Done</button>
                                                                <button type="submit" class="btn btn-sm btn-success">Approve</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                        <?php if($item->status != 'disapproved'): ?>
                                            <a href="#" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#disapproval<?php echo e($item->id); ?>">Disapprove</a>
                                            <div class="modal fade" id="disapproval<?php echo e($item->id); ?>" tabindex="0" aria-labelledby="Notes" aria-hidden="true" data-backdrop="static" data-keyboard="false" >
                                                <div class="modal-dialog modal-lg">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title text-danger">Disapproving <?php echo e($item->user->name); ?><h5>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <form action="<?php echo e(route('admin.disapprove.id', $item->id)); ?>" method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="modal-body">
                                                                <div class="row">
                                                                    <label class="col-sm-12 form-control-label">Approval Message:</label>
                                                                    <div class="col-sm-12">
                                                                        <textarea style="width: 100%" placeholder="Message" name="message" rows="5" required></textarea>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Done</button>
                                                                <button type="submit" class="btn btn-sm btn-danger">Dispprove</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div><!-- table-wrapper -->
            </div>
        </div>
        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('js'); ?>
            <script>
                function destroyUser(e) {
                    e.preventDefault();

                    if (confirm('There is no reversal to this!\nAre you sure you want to remove this item entirely from the system? '))
                        document.getElementById('delete-customer-form').submit()
                    else
                        return false;
                }
            </script>

    <?php echo $__env->make('admin.partials.dt-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u518791033/domains/web-terminal.online/public_html/resources/views/admin/ids.blade.php ENDPATH**/ ?>