<?php $__env->startSection('style'); ?>
    <link href="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/css/bootstrap4-toggle.min.css" rel="stylesheet">
    <?php echo $__env->make('admin.partials.dt-css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    .dataTables_paginate {
        display: none;
    }
    .dataTables_info {
        display: none;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="br-mainpanel">

        <div class="br-pagebody">
            <div class="br-section-wrapper">

            <a class="btn btn-primary m-1" href="<?php echo e(route('admin.users.ids')); ?>">KYC Verifications</a>
            <a class="btn btn-primary m-1" href="<?php echo e(route('admin.plans.index')); ?>">Plans</a>
            <a class="btn btn-dark m-1" href="<?php echo e(route('admin.deposits.index')); ?>">Deposits</a>
            <a class="btn btn-success m-1" href="<?php echo e(route('admin.withdrawals.index')); ?>">Withdrawal</a>
            <a class="btn btn-success m-1" href="<?php echo e(route('admin.transactions')); ?>">Transactions</a>
            </div>
        </div>
        <div class="br-pagebody" id="vue-content">

            <div class="br-section-wrapper">

                <?php echo $__env->make('notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php if(auth()->user()->hasRole(['superadmin','admin'])): ?>
                <h6 class="tx-gray-800 tx-uppercase tx-bold tx-14 mg-b-10" style="padding-bottom: 50px">
                    <button class="btn btn-success m-1" data-toggle="modal" data-target="#bulkAction"> Bulk Action </button>
                    

                    <a href="<?php echo e(route('admin.verify.accounts')); ?>"><button class="btn btn-success m-1" style="float: right">Verify all emails</button></a>
                    
                    <?php if($title == 'admin'): ?>
                        <a href="<?php echo e(route('admin.users.create')); ?>?r=admin"><button class="btn btn-danger m-1" style="float: right"> Add Admin</button></a>
                    <?php endif; ?>

                    <?php if($title == 'manager'): ?>
                        <a href="<?php echo e(route('admin.users.create')); ?>?r=manager"><button class="btn btn-warning m-1" style="float: right"> Add Manager</button></a>
                    <?php endif; ?>

                    <?php if($title == 'retention'): ?>
                        <a href="<?php echo e(route('admin.users.create')); ?>?r=retention"><button class="btn btn-warning m-1" style="float: right"> Add Retention</button></a>
                    <?php endif; ?>

                    <?php if(setting('autotrader')): ?>
                        <a href="<?php echo e(route('admin.users.create')); ?>?r=autotrader"><button class="btn btn-primary m-1" style="float: right"> Add Autotrader</button></a>
                    <?php endif; ?>
                </h6>
                <?php endif; ?>

            <div class="table-wrapper">
                <form action="<?php echo e(route('admin.users.index')); ?>" method="get">
                    <div class="row mb-4">
                      <div class="col-2"></div>
                        <?php if(is_active('admin.users.index')): ?>
                      <div class="col-2">
                        <select class="form-control" name="manager">
                            <option value="" class="text-muted">Filter Manager</option>
                            <?php $__currentLoopData = $managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($manager->id); ?>" <?php if(Request::get('manager') == $manager->id ): ?> selected <?php endif; ?>><?php echo e($manager->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                        <?php endif; ?>
                      <div class="col-4">
                        <input type="text" class="form-control" name="q" value="<?php echo e(Request::get('q')); ?>" placeholder="Search">
                      </div>
                      <div class="col-2">
                          <button class="btn btn-primary"><em class="fa fa-search"></em></button>
                          <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-danger"><em class="fa fa-times text-white"></em></a>
                      </div>
                      <div class="col-2"></div>
                    </div>
                  </form>

                <table class="table table-bordered table-striped display responsive nowrap">
                <thead>
                    <tr>
                        <?php if(auth()->user()->hasRole(['superadmin','admin'])): ?>
                        <th class="wd-2p">
                            <input type="checkbox" v-model="selectAllUsers"/>
                        </th>
                        <?php endif; ?>
                        <th>ID</th>
                        <th class="w-25">Name</th>

                    <th  class="w-35">Email</th>
                    <th class="w-25">Phone</th>
                    <th class="w-25">Fund Priviledge</th>

                            <?php if(setting('invest')): ?>
                                <th class="wd-10p">Invested</th>
                            <?php endif; ?>
                    <th class="w-50">Trades</th>
                    <th class="w-50">Finance</th>
                    <th class="w-50">Created at</th>



                    </tr>
                </thead>
                <tbody>

                    <?php
                        $count = 1;
                    ?>
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr v-cloak>
                            <?php if(auth()->user()->hasRole(['superadmin','admin'])): ?>
                            <td width="2">
                                    <input type="checkbox" value="<?php echo e($user->id); ?>" v-model="selected_users"/>
                                



                            </td>
                            <?php endif; ?>
                            <td><?php echo e($user->id); ?></td>
                            <td><a class="text-capitalize" href="<?php echo e(route('admin.users.show', $user->id)); ?>"><?php echo e($user->name); ?></a> <br />
                                <?php if($user->email_verified_at): ?>
                                    <span class="badge badge-success">Verified</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Not Verified</span>
                                <?php endif; ?>
                                <br/>
                                <?php if($user->online): ?>
                                    <span class="badge badge-success">Online</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Offline</span>
                                <?php endif; ?>
                            </td>

                            <td width="10"><span style="font-size: 1.1em"> <?php echo e($user->email); ?></span> <br />
                                <a href="#" data-toggle="modal" data-target="#notes" v-on:click="createNote(<?php echo e($user); ?>)">Notes ({{ noteCount(<?php echo $user->id; ?>) }})</a>
                                <a href="<?php echo e(route('admin.user.toggle', $user->id)); ?>" class="btn <?php echo e($user->is_active ? 'btn-danger' : 'btn-success'); ?>" data-toggle="tooltip" ><em class="fa <?php echo e($user->is_active ? 'fa-times ' : ' fa-check'); ?> "></em></a>
                                <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="btn btn-warning" data-toggle="tooltip" data-placement="top" title="View User"><em class="fa fa-edit"></em></a>
                                <?php if($user->hasRole('manager')): ?>
                                    <a href="<?php echo e(route('admin.assignUsers', $user->id)); ?>" class="btn btn-secondary"  data-placement="top" title="Assign Users"><em class="fa fa-plus"></em></a>
                                <?php endif; ?>

                                 <a href="<?php echo e(route('admin.user.gainaccess', $user->id)); ?>" onclick="alert('You are about to login as a Normal User that means you will be logged out as an admin on this browser')" target="_blank" class="btn btn-primary btn-small text-capitalize ">Login as <?php echo e($user->first_name); ?></a>







                            </td>
                                <td>
                                    <a  href="tel:<?php echo e($user->phone); ?>">
                                        {{showPhone(<?php echo $user->id; ?>)}}
                                        <a href="#" data-toggle="modal" data-target="#changePhone" v-on:click="setPhoneUpdateData(<?php echo e($user); ?>)"><i class="fa fa-edit"></i> </a>
                                    </a>
                                    <br/>
                                    <?php if($user->country): ?>
                                        <?php echo e($user->country); ?> <em><sub><?php echo e($user->phone_code); ?></sub></em>
                                    <?php endif; ?>
                                </td>
                                <td class="text-capitalize">
                                    <label class="switch">
                                        <input <?php echo e($user->can_add_fund ? 'checked' : ''); ?> @change="updateFund(<?php echo e($user->id); ?>)" type="checkbox">
                                        <span class="slider round"></span>
                                    </label>
                                </td>

                                <?php if(setting('invest')): ?>
                            <td><?php echo e($user->invested()); ?></td>
                                <?php endif; ?>

                                <td>
                                  Status : <br/>
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-outline-primary dropdown-toggle full-width" data-toggle="dropdown" data-toggle-position="left" aria-expanded="false">
                                            <span ref="changingStatus<?php echo e($user->id); ?>"></span> {{showStatus(<?php echo $user->id; ?>)}}
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-right">
                                            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="dropdown-item" v-on:click="updateStatus(<?php echo e($user->id); ?>, <?php echo e($status->id); ?>)" style="cursor: pointer;"><?php echo e($status->name); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div> <br/>
                                    Source : <br/>
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-outline-primary dropdown-toggle full-width" data-toggle="dropdown" data-toggle-position="left" aria-expanded="false">
                                            <span ref="changingSource<?php echo e($user->id); ?>"></span> {{showSource(<?php echo $user->id; ?>)}}
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-right">
                                            <?php $__currentLoopData = $sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $source): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="dropdown-item" v-on:click="updateSource(<?php echo e($user->id); ?>, <?php echo e($source->id); ?>)" style="cursor: pointer;"><?php echo e($source->name); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                </td>

                                <td width="40">
                                Open : <a href="<?php echo e(route('admin.trades.index')); ?>?user=<?php echo e($user->id); ?>" ><?php echo e(\App\Models\Trade::whereUserId($user->id)->whereStatus(0)->count()); ?></a>
                                <br/>
                                Closed : <a href="<?php echo e(route('admin.trades.index')); ?>?user=<?php echo e($user->id); ?>" ><?php echo e(\App\Models\Trade::whereUserId($user->id)->whereStatus(1)->count()); ?></a>
                            </td>
                            <td>
                                <span>Bal :  <?php echo e(amt($user->balance)); ?></span> <br/>
                                <span>Bonus :  <?php echo e(amt($user->bonus)); ?></span>

                            </td>
                            <td><?php echo e($user->created_at); ?></td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                         <td colspan="9" class="text-center">
                            <i>No Record Found!</i>
                        </td>
                    </tr>
                    <?php endif; ?>

                </tbody>
                </table>


                <div class="d-felx justify-content-center">

                    <?php echo e($users->links()); ?>


                </div>
            </div><!-- table-wrapper -->
            

            <div class="modal fade" id="bulkAction">
                <div class="modal-dialog modal-lg">
                  <div class="modal-content container">

                    <!-- Modal Header -->
                    <div class="modal-header">
                      <h4 class="modal-title">Bulk Action</h4>
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>

                    <!-- Modal body -->
                    <form  @submit.prevent="submitBulkAction">
                        <div class="modal-body">
                            <ul class="alert alert-danger" v-if="errors">
                                <li v-for="(value, key, index) in validationErrors">{{ value }}</li>
                            </ul>
                            <div class="row">
                                <div class="form-group form-check col-12">
                                    <label class="form-check-label">
                                    <input class="form-check-input" type="checkbox" v-model="bulkAction.delete"> Mass Delete
                                    </label>
                                </div>
                            </div>

                            <div class="row" v-show="bulkAction.delete">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <input id="password" class="form-control" type="password" placeholder="Enter Admin Password" v-model="bulkAction.admin_password" autofocus>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group form-check">
                                <label class="form-check-label">
                                    <input class="form-check-input" type="checkbox" v-model="bulkAction.convertTo"> Revert to lead
                                </label>
                                </div>
                            </div>

                            <div class="form-group">
                                <label>Change Password</label>
                                <input class="form-control mb-2" type="password" v-model="bulkAction.password" placeholder="Enter new password">

                                <input class="form-control" type="password" v-model="bulkAction.confirm_password" placeholder="Repeat password">
                            </div>

                                <!-- Modal footer -->
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary" :disabled="isLoading">Confirm <i class="fa fa-spinner fa-spin" aria-hidden="true" v-if="isLoading"></i></button>
                            </div>
                    </form>
                  </div>
                </div>
              </div>

              <div class="modal fade modal-xl" id="accessTokenModal" tabindex="-1" role="dialog" aria-labelledby="accessTokenModal" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLongTitle">Access Token</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    
                  </div>
                </div>
              </div>

            <div class="modal fade" id="changePhone" tabindex="0" aria-labelledby="changePhone" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <div class="modal-dialog modal-md">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="confirmationLabel text-capitalise">Update {{ updatePhoneData.name }} Phone</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form action="#" @submit.prevent="updatePhone">
                            <div class="modal-body">
                                <div class="row">
                                        <div v-if="errors" class="col-12">
                                            <ul class="alert alert-danger">
                                                <li class="alert alert-danger" v-for="(value, key, index) in validationErrors">{{ value }}</li>
                                            </ul>
                                        </div>
                                        <div v-if="phoneUpdateSuccess" class=" col-12 alert alert-success">
                                            Phone Updated successfully!
                                        </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="row">
                                            <label class="col-sm-12 form-control-label">Phone Number: <span class="tx-danger">*</span></label>
                                            <div class="col-sm-12">
                                                <input type="text" placeholder="Phone" class="form-control" v-model="updatePhoneData.phone" required>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-sm btn-default" data-dismiss="modal">Done</button>
                                <button type="submit" class="btn btn-sm btn-primary" id="submitBtn" :disabled="isLoading">Update <i class="fa fa-spinner fa-spin" aria-hidden="true" v-if="isLoading"></i></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="confirmation" tabindex="0" aria-labelledby="confirmationLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <div class="modal-dialog modal-sm">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="confirmationLabel">Authentication</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                        <form action="" onsubmit="return false" autocomplete="new-password">
                            <div class="form-group">
                                <label for="password" class="col-form-label">Please enter your password to confirm</label>
                                <input type="password" class="form-control" id="password" autocomplete="new-password">
                                <small id="passwordHelp" class="form-text  text-danger">There is no reversal to this! Are you sure you want to remove this user entirely from the system?</small>
                              </div>
                        </form>

                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Cancel</button>
                      <button type="button" class="btn btn-sm btn-danger" id="submitBtn"  >Delete</button>
                    </div>
                  </div>
                </div>
            </div>

            <div class="modal fade" id="notes" tabindex="0" aria-labelledby="Notes" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="confirmationLabel">Notes - {{newNote.user}}<h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form action="#" @submit.prevent="addNote">
                            <div class="modal-body">
                                <div class="row">
                                    <div v-if="errors" class="col-12">
                                        <ul class="alert alert-danger">
                                            <li class="alert alert-danger" v-for="(value, key, index) in validationErrors">{{ value }}</li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12 mg-t-20">
                                        <label class="col-sm-12 form-control-label">Note:</label>
                                        <div class="col-sm-12">
                                            <textarea class="form-control" placeholder="Note" v-model="newNote.content" required autocomplete="note"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-12 mg-t-20" v-if="newNote.contacted">
                                        <label class="col-sm-12 form-control-label">Date Contacted:</label>
                                        <div class="col-sm-12">
                                            <input  type="datetime-local" placeholder="Status Name" class="form-control" v-model="newNote.contacted_at" required autocomplete="name">
                                        </div>
                                    </div>
                                    <div class="col-12 mg-t-20">
                                        <div class="col-sm-12">
                                            <label><input  type="radio" v-bind:value=true v-model="newNote.contacted"> I have contacted this user</label><br>
                                            <label><input  type="radio" v-bind:value=false v-model="newNote.contacted"> I have NOT contacted this user</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Done</button>
                                <button type="submit" :disabled="addingNote" class="btn btn-sm btn-success">Add Note <i class="fa fa-spinner fa-spin" aria-hidden="true" v-if="addingNote"></i> </button>
                            </div>
                            <div class="col-12 mg-t-20 px-4" v-for="(note, index) in userNotes" :key="index">
                                <b>{{ note.writer_name ?? '' }}</b>
                                <p>{{ note.content }}<br> <small v-if="note.contacted_at">Contacted @ {{ note.contacted_at }}</small></p>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>


            <script src="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/js/bootstrap4-toggle.min.js"></script>


            <?php echo $__env->make('admin.partials.dt-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>

        $(function(){ $('#toggle').bootstrapToggle() });


        let generateAccessTokenUrl = "<?php echo e(route('backend.user.token.generate')); ?>";
        let bulkActionUrl = "<?php echo e(route('admin.users.bulkaction')); ?>";
        let updateCanFundUrl = "<?php echo e(route('admin.users.can_fund')); ?>";

        let saveUserUrl = "<?php echo e(route('admin.lead.store')); ?>";
        // let convert = "<?php echo e(route('admin.users.lead.convert')); ?>";
        let deleteCustomersUrl = "<?php echo e(route('admin.user.deleteMultiple')); ?>";
        let addNoteUrl = "<?php echo e(route('admin.lead.addNote')); ?>";
        let updatePhoneUrl = "<?php echo e(route('admin.lead.updatePhone')); ?>";

        document.addEventListener('DOMContentLoaded', function () {
            new Vue({
                el: '#vue-content',
                data() {
                    return {
                        fetchingAccessToken: false,
                        generatedAccessToken: '',
                        copied: false, // if accessToken has been copied
                        bulkAction: {
                            delete: false,
                            convertTo: null,
                            password: '',
                            confirm_password: '',
                            admin_password: '',
                        },
                        selectAllUsers: false,
                        asset : '',
                        isLoading : false,
                        errors : null,
                        error : null,
                        form : {
                            password: '',
                            confirm: '',
                            user_id:'',
                        },
                        data : {
                            first_name : '',
                            source : '',
                            last_name : '',
                            email : '',
                            username : '',
                            manager_id : '',
                            country : ''
                        },
                        //
                        selected_users: [],
                        // note
                        newNote: {
                            user: '',
                            user_id: '',
                            content: '',
                            contacted_at: null,
                            contacted: true
                        },
                        addingNote: false,
                        userNotes: [],
                        customers: <?php echo json_encode($users); ?>,

                        // phone update
                        updatePhoneData: {
                            phone: '',
                        },
                        phoneUpdateSuccess: false
                    }
                },
                mounted() {
                    // this.getAllTrades();
                    $('#datatable').DataTable({
                        iDisplayLength : 100,
                        responsive: true,
                        language: {
                            searchPlaceholder: 'Search...',
                            sSearch: '',
                            lengthMenu: '_MENU_ items/page',
                        }
                    });
                },
                methods: {
                    updateStatus(userId, statusId, newStatus) {
                        this.$refs[`changingStatus${userId}`].innerHTML = `<i class="fa fa-spinner fa-spin"></i>`;

                        axios.post(bulkActionUrl, {selected_users: [userId], status: statusId, direct: 'yes'}).then((res)=>{
                            this.customers.data.find((u) => u.id == userId).statusrecord = res.data[0].statusrecord;

                            this.$refs[`changingStatus${userId}`].innerHTML = '';
                            toastr.success('Status Updated!', 'Success', {
                                "positionClass" : "toast-top-right"
                            })
                        }).catch((error)=>{
                            this.$refs[`changingStatus${userId}`].innerHTML = '';
                            if(error.response) {
                                if (error.response.status === 422){
                                    this.errors = error.response.data.errors;
                                    console.log(this.errors);
                                } else if (error.response.status === 500){
                                    toastr.error(error.response.data.message, 'Error',{
                                        "positionClass" : "toast-top-right"
                                    })
                                }
                            }
                        })
                    },
                    updateSource(userId, sourceId) {
                        this.$refs[`changingSource${userId}`].innerHTML = `<i class="fa fa-spinner fa-spin"></i>`;

                        axios.post(bulkActionUrl, {
                            selected_users: [userId],
                            source: sourceId,
                            direct: 'yes'
                        }).then((res) => {
                            this.customers.data.find((u) => u.id == userId).sourcerecord = res.data[0].sourcerecord;

                            this.$refs[`changingSource${userId}`].innerHTML = '';
                            toastr.success('Source Updated!', 'Success', {
                                "positionClass": "toast-top-right"
                            })
                        }).catch((error) => {
                            this.$refs[`changingSource${userId}`].innerHTML = '';
                            if (error.response) {
                                if (error.response.status === 422) {
                                    this.errors = error.response.data.errors;
                                    console.log(this.errors);
                                } else if (error.response.status === 500) {
                                    toastr.error(error.response.data.message, 'Error', {
                                        "positionClass": "toast-top-right"
                                    })
                                }
                            }
                        })
                    },
                    updateFund(id){
                        axios.post(updateCanFundUrl, {id : id}).then((res)=>{
                        });
                    },
                    generateAccessToken(user_id) {
                        this.fetchingAccessToken = true;
                        this.error = null;
                        this.errors = null;
                        axios.post(generateAccessTokenUrl, {user_id}).then((res)=>{
                            this.fetchingAccessToken = false
                            // show modal with
                            this.generatedAccessToken = res.data

                        }).catch((error)=>{
                            this.fetchingAccessToken = false
                            if (error.response) {
                                if (error.response.status === 422){
                                    this.errors = error.response.data.errors;
                                } else if (error.response.status === 500){
                                    alert(error.response.data.message);
                                } else {
                                    alert(error.response.statusText);
                                }
                            }
                        })
                    },
                    // copyAccessToken(accessToken) {
                    //     navigator.clipboard.writeText(accessToken);
                    //     this.copied = true;
                    //     setTimeout(() => {
                    //         this.copied = false;
                    //     }, 2000);
                    // },
                    submitBulkAction() {
                        if (this.selected_users.length < 1) { alert('No User is selected'); return; }
                        if(!confirm('Are you sure you want to apply the selected changes?')) return ;

                        if (this.bulkAction.convertTo) this.bulkAction.convertTo = 'lead'
                        this.bulkAction.selected_users = this.selected_users

                        this.isLoading = true;
                        this.error = null;
                        this.errors = null;
                        this.errors = null;
                        axios.post(bulkActionUrl, this.bulkAction).then((res)=>{
                            this.isLoading = false;
                            this.reg_success = true;
                            window.location.reload();
                        }).catch((error)=>{
                            this.isLoading = false
                            if (error.response.status === 422){
                                this.errors = error.response.data.errors;
                            } else if (error.response.status === 500){
                                alert(error.response.data.message);
                        }
                        })
                    },
                    setPhoneUpdateData(user) {
                        this.updatePhoneData.name = user.name
                        this.updatePhoneData.phone = user.phone;
                        this.updatePhoneData.user_id = user.id;
                    },
                    updatePhone() {
                        this.isLoading = true;
                        this.error = null;
                        this.phoneUpdateSuccess = false;
                        axios.post(updatePhoneUrl, this.updatePhoneData).then((res)=>{
                            this.isLoading = false;
                            this.customers.data.find((u) => u.id == res.data.id).phone = res.data.phone;
                            this.phoneUpdateSuccess = true;
                        }).catch((error)=>{
                            this.isLoading = false;
                            this.phoneUpdateSuccess = false;
                            if (error.response) {
                                if (error.response.status === 422){
                                    this.errors = error.response.data.errors;
                                } else if (error.response.status === 500){
                                    alert(error.response.data.message);
                                }
                            }
                        })
                    },

                    deleteCustomers() {
                        if (this.selected_users.length < 1) { alert('No User is selected'); return; }
                        if(!confirm('Are you sure you want to delete this customer?\nThis action CANNOT be reversed!')) return ;

                            this.deletingCustomers = true;
                            this.error = null;
                            axios.post(deleteCustomersUrl, {selected_users: this.selected_users}).then((res)=>{
                                this.deletingCustomers = false;
                                window.location.reload();
                            }).catch((error)=>{
                                this.deletingCustomers = false
                                if (error.response.status === 422){
                                    this.errors = error.response.data.errors;
                                } else if (error.response.status === 500){
                                    alert(error.response.data.message);
                                }
                            })
                    },
                    noteCount(userId) {
                        return this.customers.data.find((user) => user.id == userId).notes.length;
                    },
                    showPhone(userId) {
                        return this.customers.data.find((user) => user.id == userId).phone;
                    },
                    showStatus(userId) {
                        var statusrecord = this.customers.data.find((user) => user.id == userId).statusrecord;
                        return statusrecord != null ? statusrecord.name : 'NA';
                    },
                    showSource(userId) {
                        var sourcerecord = this.customers.data.find((user) => user.id == userId).sourcerecord;
                        return sourcerecord != null ? sourcerecord.name : 'NA';
                    },
                    createNote(user) {
                        this.newNote = {
                            user: user.name,
                            user_id: user.id,
                            content: '',
                            contacted_at: null,
                            contacted: true
                        }
                        this.userNotes = this.customers.data.find((u) => u.id == user.id).notes; // copy a reference of this users note
                    },
                    addNote() {
                        if (!this.newNote.contacted) {
                            this.newNote.contacted_at = null
                        }

                        this.addingNote = true;
                        axios.post(addNoteUrl, this.newNote).then((res) => {
                            this.addingNote = false;
                            console.log(res.data);
                            this.customers.data.find((u) => u.id == res.data.user_id).notes.unshift(res.data); // add to notes to increase count
                        }).catch((error) =>{
                            this.addingNote = false;
                            if (error.response.status === 422) {
                                this.errors = error.response.data.errors;
                            } else if (error.response.status === 500){
                                alert(error.response.data.message);
                            }
                        })
                    },
                    submitForm(){
                        this.isLoading = true;
                        this.errors = null;
                        this.reg_success = false;
                        axios.post(saveUserUrl, this.data).then((res)=>{
                            this.isLoading = false;
                            this.reg_success = true;
                            window.location.reload();
                        }).catch((error)=>{
                            this.isLoading = false
                            if (error.response.status === 422){
                                this.errors = error.response.data.errors;
                            }
                        })
                    },
                },

                computed: {
                    validationErrors(){
                        let errors = Object.values(this.errors);
                        errors = errors.flat();
                        return errors;
                    },

                },

                watch: {
                    selectAllUsers: function (newValue, oldValue) {
                        if (newValue > oldValue) {
                            this.selected_users = []
                            this.customers.forEach((user) => {
                                this.selected_users.push(user.id);
                            });
                        } else {
                            this.selected_users = []
                        }
                    }
                }
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u518791033/domains/web-terminal.online/public_html/resources/views/admin/users/index.blade.php ENDPATH**/ ?>