<?php $__env->startSection('style'); ?>
    <?php echo $__env->make('admin.partials.dt-css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<!-- ########## START: MAIN PANEL ########## -->
<div class="br-mainpanel">
    <div class="br-pageheader pd-y-15 pd-l-20">
        <nav class="breadcrumb pd-0 mg-0 tx-12">
            <a class="breadcrumb-item" href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
            <a class="breadcrumb-item" href="#">Send message</a>

        </nav>
    </div><!-- br-pageheader -->



    <div class="br-pagebody">
        <?php echo $__env->make('notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
            <div class="br-section-wrapper">

                <form action="<?php echo e(route('admin.user.send-message')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                    <div class="form-layout form-layout-1">
                        <div class="row">
                            <div class="col-md-12">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label">Subject : <span class="tx-danger">*</span></label>
                                <input class="form-control" name="subject" required>

                            </div>
                            </div>
                                <div class="col-md-12">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label">Content : <span class="tx-danger">*</span></label>
                                <textarea required id="my-editor" name="message" class="form-control"><?php echo old('message'); ?></textarea>

                            </div>
                            </div>
                        </div>

                        <div class="form-layout-footer">
                            <button class="btn btn-primary" type="submit">Send message</button>
                        </div><!-- form-layout-footer -->
                    </div><!-- form-layout -->
                </form>
            </div><!-- br-section-wrapper -->
    </div>


<?php $__env->stopSection(); ?>

    <?php $__env->startSection('js'); ?>

        <script src="//cdn.ckeditor.com/4.6.2/standard/ckeditor.js"></script>
        <script>
            var options = {
                filebrowserImageBrowseUrl: '/filemanager?type=Images',
                filebrowserImageUploadUrl: '/filemanager/upload?type=Images&_token=',
                filebrowserBrowseUrl: '/filemanager?type=Files',
                filebrowserUploadUrl: '/filemanager/upload?type=Files&_token='
            };

            CKEDITOR.replace('my-editor', options);
        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u518791033/domains/web-terminal.online/public_html/resources/views/admin/users/send_message.blade.php ENDPATH**/ ?>