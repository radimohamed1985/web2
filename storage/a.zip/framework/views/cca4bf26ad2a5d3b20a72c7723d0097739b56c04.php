<?php $__env->startSection('content'); ?>
<!-- ########## START: MAIN PANEL ########## -->
<div class="br-mainpanel">
    <div class="br-pageheader pd-y-15 pd-l-20">
        <nav class="breadcrumb pd-0 mg-0 tx-12">
            <a class="breadcrumb-item" href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
            <span class="breadcrumb-item active"> Currency Pairs Layouts</span>
        </nav>
    </div><!-- br-pageheader -->
    <div class="pd-x-20 pd-sm-x-30 pd-t-20 pd-sm-t-30">
        <h4 class="tx-gray-800 mg-b-5"> Currency Pair</h4>
    </div>

    <div class="br-pagebody">
        <?php echo $__env->make('notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="br-section-wrapper">
            <h6 class="tx-gray-800 tx-uppercase tx-bold tx-14 mg-b-10">Update Currency Pair (enter base currency for forex and crypto)</h6>

            <form action="<?php echo e(route('admin.currencies.update', $currency_pair->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <div class="form-layout form-layout-1">
                    <div class="row mg-b-25">

                        <div class="col-md-3">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label"> Title / Name: <span class="tx-danger">*</span></label>
                                <input class="form-control" value="<?php echo e(old('name', optional($currency_pair)->name)); ?>" required type="text" name="name" placeholder="Enter Name">
                            </div>
                        </div><!-- col-8 -->

                        <div class="col-md-3">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label"> Symbol (BTC): <span class="tx-danger">*</span></label>
                                <input class="form-control" value="<?php echo e(old('sym', optional($currency_pair)->sym)); ?>" required type="text" name="sym" placeholder="Enter Symbol">
                            </div>
                        </div><!-- col-8 -->

                        <div class="col-md-3">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label"> Exchange & Pair : <span class="tx-danger">*</span></label>
                                <input class="form-control" value="<?php echo e(old('ex_sym', optional($currency_pair)->ex_sym)); ?>" required type="text" name="ex_sym" placeholder="Enter Exchange & Pair">
                            </div>
                        </div><!-- col-8 -->
                        <div class="col-md-3">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label"> Base Currency (USD):</label>
                                <input class="form-control" value="<?php echo e(old('ex_sym', optional($currency_pair)->base)); ?>" type="text" name="base" placeholder="base currency">
                            </div>
                        </div><!-- col-8 -->

                        <div class="col-md-4">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label">Type (Crypto): <span class="tx-danger">*</span></label>
                                <select class="form-control" name="type">
                                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option class="text-capitalize" <?php echo e($currency_pair->type === $item ? 'selected' : ''); ?> value="<?php echo e($item); ?>"><?php echo e($item); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div><!-- col-8 -->
                        <div class="col-md-4">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label">Leverage: <span class="tx-danger">*</span></label>
                                <input  class="form-control" value="<?php echo e(old('leverage', optional($currency_pair)->leverage)); ?>" required type="number" step="any" name="leverage" placeholder="Enter leverage">
                            </div>
                        </div><!-- col-8 -->
                        <div class="col-md-4">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label">Image :  <span class="tx-danger">*</span></label>
                                <?php echo $__env->make('admin.partials.image-upload',['field' => 'image','image' => $currency_pair->image,'id' => 'img'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div><!-- col-8 -->

                        <div class="col-md-3">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label">Commission (%): <span class="tx-danger">*</span></label>
                                <input  class="form-control" value="<?php echo e(old('com',$currency_pair->com)); ?>" required type="number" step="any" name="com" placeholder="Enter Commission">
                            </div>
                        </div><!-- col-8 -->

                        <div class="col-md-3">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label">Buy Spread (%): <span class="tx-danger">*</span></label>
                                <input  class="form-control" value="<?php echo e(old('buy_spread',$currency_pair->buy_spread)); ?>" min="0" required type="number" step="any" name="buy_spread" placeholder="Enter Buy Spread">
                            </div>
                        </div><!-- col-8 -->
                        <div class="col-md-3">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label">Sell Spread (%): <span class="tx-danger">*</span></label>
                                <input  class="form-control" value="<?php echo e(old('sell_spread',$currency_pair->sell_spread)); ?>" min="0" required type="number" step="any" name="sell_spread" placeholder="Enter Sell Spread">
                            </div>
                        </div><!-- col-8 -->
                        <div class="col-md-3">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label">Can be traded: <span class="tx-danger">*</span></label>
                                <select name="disabled" class="form-control">
                                    <option <?php echo e($currency_pair->disabled ? ' ' : 'selected'); ?> value="0">Yes</option>
                                    <option  <?php echo e($currency_pair->disabled ? 'selected' : ''); ?>  value="1">No</option>
                                </select>
                            </div>
                        </div><!-- col-8 -->

                        <div class="col-md-12">
                            <div class="form-group mg-b-10-force">
                                <button class="btn btn-primary" type="submit">Update Form</button>
                            </div>
                        </div><!-- col-8 -->




                        <!-- col-8 -->
                        
                        

                        
                    </div><!-- row -->
                </div><!-- form-layout -->
            </form>
        </div><!-- br-section-wrapper -->
    </div>

<!-- ########## END: MAIN PANEL ########## -->

        <?php $__env->startSection('js'); ?>
            <script src="<?php echo e(asset('lib/jquery-ui/jquery-ui.js')); ?>"></script>
            <script src="<?php echo e(asset('lib/jquery-switchbutton/jquery.switchButton.js')); ?>"></script>
            <script src="<?php echo e(asset('lib/peity/jquery.peity.js')); ?>"></script>
            <script src="<?php echo e(asset('lib/datatables/jquery.dataTables.js')); ?>"></script>
            <script src="<?php echo e(asset('lib/datatables-responsive/dataTables.responsive.js')); ?>"></script>
            <script src="<?php echo e(asset('lib/select2/js/select2.min.js')); ?>"></script>
            <script src="<?php echo e(asset('lib/highlightjs/highlight.pack.js')); ?>"></script>
            <script>
                $(function(){
                    'use strict';

                    $('#datatable1').DataTable({
                        responsive: true,
                        language: {
                            searchPlaceholder: 'Search...',
                            sSearch: '',
                            lengthMenu: '_MENU_ items/page',
                        }
                    });

                    $('#datatable2').DataTable({
                        bLengthChange: false,
                        searching: false,
                        responsive: true
                    });

                    // Select2
                    $('.dataTables_length select').select2({ minimumResultsForSearch: Infinity });

                });
            </script>
       <?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u518791033/domains/web-terminal.online/public_html/resources/views/admin/currencies/edit.blade.php ENDPATH**/ ?>